import express from 'express';
import cookieParser from 'cookie-parser';
import { checkDatabaseConnection } from '../server/db.ts';
import { authRouter } from '../server/routes/auth.routes.ts';
import { userRouter } from '../server/routes/user.routes.ts';
import { MemoryDatabase } from '../server/services/memory-db.ts';

async function runApiIntegrationTests() {
  console.log('====================================================');
  console.log('KAMCH ERP — USER MANAGEMENT API INTEGRATION SUITE');
  console.log('====================================================\n');

  // Initialize DB connection check (sets fallback if MySQL service is not local)
  await checkDatabaseConnection();

  const app = express();
  app.use(express.json());
  app.use(cookieParser());
  app.use('/api/auth', authRouter);
  app.use('/api/users', userRouter);

  const server = app.listen(0);
  const address = server.address() as any;
  const baseUrl = `http://127.0.0.1:${address.port}`;

  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string, detail?: string) {
    if (condition) {
      console.log(`[PASS] ${testName}`);
      passed++;
    } else {
      console.error(`[FAIL] ${testName}${detail ? ` - Detail: ${detail}` : ''}`);
      failed++;
    }
  }

  try {
    // 1. Login as Super Admin
    console.log('--- 1. Super Admin Authentication & Session Setup ---');
    const loginRes = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usernameOrEmail: 'superadmin', password: 'Admin@12345' }),
    });

    const cookieHeader = loginRes.headers.get('set-cookie');
    const sessionCookie = cookieHeader ? cookieHeader.split(';')[0] : '';
    const loginData = await loginRes.json();

    assert(loginRes.status === 200, 'Super Admin login returns HTTP 200');
    assert(loginData.user?.role === 'SUPER_ADMIN', 'Logged in user has role SUPER_ADMIN');
    assert(Boolean(loginData.csrfToken), 'CSRF token returned');
    assert(Boolean(sessionCookie), 'HTTP-only session cookie returned');

    const csrfToken = loginData.csrfToken;
    const authHeaders = {
      'Content-Type': 'application/json',
      'Cookie': `${sessionCookie}; kamch_csrf=${csrfToken}`,
      'X-CSRF-Token': csrfToken,
    };

    // 2. Fetch Users List as Super Admin (Must see Super Admin)
    console.log('\n--- 2. Directory Listing: Super Admin Visibility ---');
    const superAdminListRes = await fetch(`${baseUrl}/api/users`, { headers: authHeaders });
    const superAdminListData = await superAdminListRes.json();
    assert(superAdminListRes.status === 200, 'GET /api/users returns HTTP 200 for Super Admin');
    const hasSuperAdminInList = superAdminListData.users.some((u: any) => u.role === 'SUPER_ADMIN');
    assert(hasSuperAdminInList, 'Super Admin account is visible to Super Admin in directory');

    // 3. Login as Principal
    console.log('\n--- 3. Principal Directory Listing & Super Admin Protection ---');
    const principalLoginRes = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usernameOrEmail: 'principal', password: 'Principal@12345' }),
    });
    const principalCookie = principalLoginRes.headers.get('set-cookie')?.split(';')[0] || '';
    const principalLoginData = await principalLoginRes.json();
    const principalCsrf = principalLoginData.csrfToken;
    const principalHeaders = {
      'Content-Type': 'application/json',
      'Cookie': `${principalCookie}; kamch_csrf=${principalCsrf}`,
      'X-CSRF-Token': principalCsrf,
    };

    assert(principalLoginRes.status === 200, 'Principal login returns HTTP 200');

    // Principal listing users (Super Admin MUST BE COMPLETELY FILTERED OUT)
    const principalListRes = await fetch(`${baseUrl}/api/users`, { headers: principalHeaders });
    const principalListData = await principalListRes.json();
    assert(principalListRes.status === 200, 'GET /api/users returns HTTP 200 for Principal');
    const hasSuperAdminInPrincipalList = principalListData.users.some((u: any) => u.role === 'SUPER_ADMIN');
    assert(!hasSuperAdminInPrincipalList, 'Super Admin account is STRICTLY HIDDEN from Principal query results');

    // Direct fetch of Super Admin by Principal (User ID 1) -> MUST RETURN HTTP 403
    const directFetchRes = await fetch(`${baseUrl}/api/users/1`, { headers: principalHeaders });
    assert(directFetchRes.status === 403, 'Direct GET /api/users/1 by Principal is rejected with HTTP 403 Forbidden');

    // Principal attempting to suspend Super Admin (User ID 1) -> MUST RETURN HTTP 403
    const directSuspendRes = await fetch(`${baseUrl}/api/users/1/suspend`, {
      method: 'PATCH',
      headers: principalHeaders,
    });
    assert(directSuspendRes.status === 403, 'PATCH /api/users/1/suspend by Principal is rejected with HTTP 403 Forbidden');

    // Principal attempting to deactivate Super Admin (User ID 1) -> MUST RETURN HTTP 403
    const directDeactivateRes = await fetch(`${baseUrl}/api/users/1/deactivate`, {
      method: 'PATCH',
      headers: principalHeaders,
    });
    assert(directDeactivateRes.status === 403, 'PATCH /api/users/1/deactivate by Principal is rejected with HTTP 403 Forbidden');

    // 4. Create Account by Principal (Allowed Account Type)
    console.log('\n--- 4. Account Provisioning by Principal & Non-Super-Admin Creation Guard ---');
    const newUsername = `faculty_${Date.now()}`;
    const newEmail = `${newUsername}@kamch.ac.in`;
    const createRes = await fetch(`${baseUrl}/api/users`, {
      method: 'POST',
      headers: principalHeaders,
      body: JSON.stringify({
        username: newUsername,
        email: newEmail,
        fullName: 'Dr. Anand Kumar, BAMS',
        roleId: 4, // HOD
        departmentId: 1, // SAMHITA_SIDDHANTA
        initialPassword: 'TempPassword@123',
        confirmPassword: 'TempPassword@123',
      }),
    });
    const createData = await createRes.json();
    assert(createRes.status === 201, 'Principal can create allowed department account (HTTP 201)');
    assert(createData.user?.mustChangePassword === true, 'Created user has mustChangePassword = true');

    // Principal attempting to create another Super Admin -> MUST RETURN HTTP 403
    const createAdminRes = await fetch(`${baseUrl}/api/users`, {
      method: 'POST',
      headers: principalHeaders,
      body: JSON.stringify({
        username: `fake_admin_${Date.now()}`,
        email: `fake_admin_${Date.now()}@kamch.ac.in`,
        fullName: 'Unauthorized Admin Candidate',
        roleId: 1, // SUPER_ADMIN
        initialPassword: 'Password@123',
        confirmPassword: 'Password@123',
      }),
    });
    assert(createAdminRes.status === 403, 'Principal attempting to create SUPER_ADMIN is rejected with HTTP 403');

    // 5. Test First-Login Flow & Password Change for Newly Created Account
    console.log('\n--- 5. First-Login Authentication & Password Change Enforcement ---');
    const newLoginRes = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usernameOrEmail: newUsername, password: 'TempPassword@123' }),
    });
    const newCookie = newLoginRes.headers.get('set-cookie')?.split(';')[0] || '';
    const newLoginData = await newLoginRes.json();
    const newCsrf = newLoginData.csrfToken;
    const newAuthHeaders = {
      'Content-Type': 'application/json',
      'Cookie': `${newCookie}; kamch_csrf=${newCsrf}`,
      'X-CSRF-Token': newCsrf,
    };

    assert(newLoginRes.status === 200, 'Temporary password allows initial login (HTTP 200)');
    assert(newLoginData.user?.mustChangePassword === true, 'Login confirms mustChangePassword is true');

    // Attempting to access protected API before password change -> MUST RETURN HTTP 403 PASSWORD_CHANGE_REQUIRED
    const protectedAccessRes = await fetch(`${baseUrl}/api/users`, { headers: newAuthHeaders });
    const protectedAccessData = await protectedAccessRes.json();
    assert(
      protectedAccessRes.status === 403 && protectedAccessData.code === 'PASSWORD_CHANGE_REQUIRED',
      'Access to protected APIs is blocked before mandatory password change (HTTP 403 PASSWORD_CHANGE_REQUIRED)'
    );

    // User changes password via /api/auth/change-password
    const changePwdRes = await fetch(`${baseUrl}/api/auth/change-password`, {
      method: 'POST',
      headers: newAuthHeaders,
      body: JSON.stringify({
        currentPassword: 'TempPassword@123',
        newPassword: 'MyPermanentPassword@2026',
      }),
    });
    assert(changePwdRes.status === 200, 'User successfully changes initial password (HTTP 200)');

    // 6. Office Staff Access Control (User Management Blocked)
    console.log('\n--- 6. Office Staff Role Restrictions ---');
    const officeLoginRes = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usernameOrEmail: 'accounts', password: 'Office@12345' }),
    });
    const officeCookie = officeLoginRes.headers.get('set-cookie')?.split(';')[0] || '';
    const officeLoginData = await officeLoginRes.json();
    const officeCsrf = officeLoginData.csrfToken;
    const officeHeaders = {
      'Content-Type': 'application/json',
      'Cookie': `${officeCookie}; kamch_csrf=${officeCsrf}`,
      'X-CSRF-Token': officeCsrf,
    };

    const officeUsersRes = await fetch(`${baseUrl}/api/users`, { headers: officeHeaders });
    assert(officeUsersRes.status === 403, 'Office staff attempting to access /api/users receives HTTP 403 Forbidden');

    // 7. Library Staff Access Control (User Management Blocked)
    console.log('\n--- 7. Library Staff Role Restrictions ---');
    const libraryLoginRes = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usernameOrEmail: 'library', password: 'Library@12345' }),
    });
    const libraryCookie = libraryLoginRes.headers.get('set-cookie')?.split(';')[0] || '';
    const libraryLoginData = await libraryLoginRes.json();
    const libraryCsrf = libraryLoginData.csrfToken;
    const libraryHeaders = {
      'Content-Type': 'application/json',
      'Cookie': `${libraryCookie}; kamch_csrf=${libraryCsrf}`,
      'X-CSRF-Token': libraryCsrf,
    };

    const libraryUsersRes = await fetch(`${baseUrl}/api/users`, { headers: libraryHeaders });
    assert(libraryUsersRes.status === 403, 'Library staff attempting to access /api/users receives HTTP 403 Forbidden');

    // 8. 6-Attempt Lockout Behavior via API
    console.log('\n--- 8. API Lockout Behavior on 6 Consecutive Failed Attempts ---');
    const lockoutTargetUsername = `lockout_test_${Date.now()}`;
    const lockoutTargetEmail = `${lockoutTargetUsername}@kamch.ac.in`;
    await fetch(`${baseUrl}/api/users`, {
      method: 'POST',
      headers: authHeaders,
      body: JSON.stringify({
        username: lockoutTargetUsername,
        email: lockoutTargetEmail,
        fullName: 'Lockout Test Target',
        roleId: 6, // STAFF
        initialPassword: 'ValidTargetPassword@123',
        confirmPassword: 'ValidTargetPassword@123',
      }),
    });

    // 5 failed attempts -> HTTP 401
    for (let attempt = 1; attempt <= 5; attempt++) {
      const failRes = await fetch(`${baseUrl}/api/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ usernameOrEmail: lockoutTargetUsername, password: 'WrongPassword' }),
      });
      assert(failRes.status === 401, `Failed attempt #${attempt} returns HTTP 401`);
    }

    // 6th failed attempt -> HTTP 403 ACCOUNT_LOCKED
    const sixthFailRes = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usernameOrEmail: lockoutTargetUsername, password: 'WrongPassword' }),
    });
    const sixthFailData = await sixthFailRes.json();
    assert(sixthFailRes.status === 403 && sixthFailData.code === 'ACCOUNT_LOCKED', '6th failed attempt triggers 30-min lockout (HTTP 403 ACCOUNT_LOCKED)');

    // Correct password during active lockout -> MUST STILL BE REJECTED with HTTP 403 ACCOUNT_LOCKED
    const bypassAttemptRes = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usernameOrEmail: lockoutTargetUsername, password: 'ValidTargetPassword@123' }),
    });
    const bypassAttemptData = await bypassAttemptRes.json();
    assert(
      bypassAttemptRes.status === 403 && bypassAttemptData.code === 'ACCOUNT_LOCKED',
      'Correct password CANNOT bypass active lockout (HTTP 403 ACCOUNT_LOCKED)'
    );

    console.log('\n====================================================');
    console.log(`TOTAL API TESTS: ${passed + failed} | PASSED: ${passed} | FAILED: ${failed}`);
    console.log('====================================================');

    server.close();
    if (failed > 0) process.exit(1);
    process.exit(0);
  } catch (err) {
    console.error('Fatal API integration error:', err);
    server.close();
    process.exit(1);
  }
}

runApiIntegrationTests();
