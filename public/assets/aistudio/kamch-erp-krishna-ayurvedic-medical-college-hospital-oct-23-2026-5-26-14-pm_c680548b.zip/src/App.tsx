import React, { useState } from 'react';
import { AppLayout } from './components/layout/AppLayout';
import { WelcomeView } from './views/WelcomeView';
import { ComponentShowcaseView } from './views/ComponentShowcaseView';
import { ModuleRoadmapView } from './views/ModuleRoadmapView';
import { ArchitectureView } from './views/ArchitectureView';
import { UserManagementView } from './views/UserManagementView';
import { FeesManagementView } from './views/FeesManagementView';
import { NavigationItemKey } from './types';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LoginModal } from './components/auth/LoginModal';
import { ChangePasswordModal } from './components/auth/ChangePasswordModal';

function AppContent() {
  const [currentTab, setCurrentTab] = useState<NavigationItemKey>('welcome');
  const { user } = useAuth();

  return (
    <AppLayout currentTab={currentTab} onSelectTab={setCurrentTab}>
      {currentTab === 'welcome' && (
        <WelcomeView onNavigate={setCurrentTab} />
      )}

      {currentTab === 'user_mgmt' && (
        ['SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY'].includes(user?.role || '') ? (
          <UserManagementView />
        ) : (
          <WelcomeView onNavigate={setCurrentTab} />
        )
      )}

      {currentTab === 'fees_mgmt' && (
        ['SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY', 'OFFICE'].includes(user?.role || '') ? (
          <FeesManagementView />
        ) : (
          <WelcomeView onNavigate={setCurrentTab} />
        )
      )}

      {currentTab === 'components' && (
        <ComponentShowcaseView />
      )}

      {currentTab === 'roadmap' && (
        <ModuleRoadmapView onNavigate={setCurrentTab} />
      )}

      {currentTab === 'architecture' && (
        <ArchitectureView />
      )}

      {![
        'welcome',
        'user_mgmt',
        'fees_mgmt',
        'components',
        'roadmap',
        'architecture',
      ].includes(currentTab) && (
        <WelcomeView onNavigate={setCurrentTab} />
      )}

      {/* Authentication Modals */}
      <LoginModal />
      <ChangePasswordModal />
    </AppLayout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
