import React, { useEffect, useState } from 'react';
import {
  Users,
  CreditCard,
  ArrowRight,
  LogIn,
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { NavigationItemKey } from '../types';
import { useAuth } from '../context/AuthContext';
import { CollegeLogo } from '../components/ui/CollegeLogo';

export interface WelcomeViewProps {
  onNavigate: (tab: NavigationItemKey) => void;
}

interface FeeQuickStats {
  totalAssessed: number;
  totalCollected: number;
  totalOutstanding: number;
  pendingReceiptCount: number;
  studentCount: number;
}

export const WelcomeView: React.FC<WelcomeViewProps> = ({ onNavigate }) => {
  const { user, openLoginModal } = useAuth();
  const [feeStats, setFeeStats] = useState<FeeQuickStats | null>(null);

  // Fetch quick fees stats if authorized
  useEffect(() => {
    if (user && ['SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY', 'OFFICE'].includes(user.role)) {
      fetch('/api/fees/stats')
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => {
          if (data && data.stats) {
            setFeeStats(data.stats);
          }
        })
        .catch(() => {
          // Ignore background stats failure
        });
    }
  }, [user]);

  const canAccessFees = user && ['SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY', 'OFFICE'].includes(user.role);
  const canAccessUsers = user && ['SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY'].includes(user.role);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0,
    }).format(val);
  };

  return (
    <div className="space-y-5">
      {/* Institutional Banner Header */}
      <div className="bg-white rounded-xl border border-stone-200/80 p-5 sm:p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-white p-1 flex items-center justify-center shrink-0 border border-[#D4AF37]/40 shadow-xs">
            <CollegeLogo size="md" className="w-full h-full" />
          </div>
          <div>
            <h1 className="font-serif text-lg sm:text-xl font-bold text-stone-900 leading-tight">
              Krishna Ayurvedic Medical College &amp; Hospital
            </h1>
            <p className="text-xs text-stone-500 mt-0.5">
              Institutional Enterprise Resource Planning
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 self-start sm:self-auto shrink-0">
          {user ? (
            <div className="flex items-center gap-2">
              <Badge variant="institutional" size="sm">
                {user.roleName}
              </Badge>
              {user.mustChangePassword && (
                <Badge variant="warning" size="sm">
                  Password Reset Required
                </Badge>
              )}
            </div>
          ) : (
            <Button
              variant="primary"
              size="sm"
              icon={<LogIn className="w-3.5 h-3.5 text-[#D4AF37]" />}
              onClick={openLoginModal}
            >
              Sign In
            </Button>
          )}
        </div>
      </div>

      {/* Operational Module Access Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
        {/* Fees Management Card */}
        <Card accentTop className="flex flex-col justify-between">
          <div>
            <CardHeader className="pb-3 border-b-0">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-[#4B2E2E]/10 flex items-center justify-center text-[#4B2E2E]">
                  <CreditCard className="w-4.5 h-4.5" />
                </div>
                <div>
                  <CardTitle>Fees Management</CardTitle>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3 pt-0">
              <p className="text-xs text-stone-600 leading-relaxed">
                Tuition fee assessments, KEA concessions, cashier collections, and Principal digital receipt authorization.
              </p>

              {canAccessFees && feeStats && (
                <div className="grid grid-cols-2 gap-2.5 pt-2">
                  <div className="bg-stone-50 p-2.5 rounded-lg border border-stone-200/70">
                    <span className="text-[10px] text-stone-500 font-medium block">Total Collected</span>
                    <span className="text-xs font-bold text-emerald-800">
                      {formatCurrency(feeStats.totalCollected)}
                    </span>
                  </div>
                  <div className="bg-stone-50 p-2.5 rounded-lg border border-stone-200/70">
                    <span className="text-[10px] text-stone-500 font-medium block">Pending Receipts</span>
                    <span className="text-xs font-bold text-amber-800">
                      {feeStats.pendingReceiptCount} Pending
                    </span>
                  </div>
                </div>
              )}
            </CardContent>
          </div>

          <div className="p-5 pt-0">
            {canAccessFees ? (
              <Button
                variant="primary"
                size="sm"
                className="w-full justify-center"
                icon={<ArrowRight className="w-3.5 h-3.5" />}
                iconPosition="right"
                onClick={() => onNavigate('fees_mgmt')}
              >
                Open Fees Management
              </Button>
            ) : (
              <Button
                variant="outline"
                size="sm"
                disabled={!user}
                className="w-full justify-center text-xs"
                onClick={user ? undefined : openLoginModal}
              >
                {user ? 'Restricted to Accounts & Administration' : 'Sign In Required'}
              </Button>
            )}
          </div>
        </Card>

        {/* User Management Card */}
        <Card accentTop className="flex flex-col justify-between">
          <div>
            <CardHeader className="pb-3 border-b-0">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-[#4B2E2E]/10 flex items-center justify-center text-[#4B2E2E]">
                  <Users className="w-4.5 h-4.5" />
                </div>
                <div>
                  <CardTitle>User Management</CardTitle>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3 pt-0">
              <p className="text-xs text-stone-600 leading-relaxed">
                Institutional role-based access control, account provisioning, security locks, and audit activity.
              </p>

              {user && (
                <div className="p-2.5 bg-stone-50 rounded-lg border border-stone-200/70 text-xs space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-stone-500">Active Account:</span>
                    <span className="font-semibold text-stone-800">{user.username}</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-stone-500">Role:</span>
                    <span className="font-mono text-[#4B2E2E] font-medium">{user.role}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </div>

          <div className="p-5 pt-0">
            {canAccessUsers ? (
              <Button
                variant="primary"
                size="sm"
                className="w-full justify-center"
                icon={<ArrowRight className="w-3.5 h-3.5" />}
                iconPosition="right"
                onClick={() => onNavigate('user_mgmt')}
              >
                Open User Management
              </Button>
            ) : (
              <Button
                variant="outline"
                size="sm"
                disabled={!user}
                className="w-full justify-center text-xs"
                onClick={user ? undefined : openLoginModal}
              >
                {user ? 'Restricted to Administrators' : 'Sign In Required'}
              </Button>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};
