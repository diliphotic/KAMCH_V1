import React, { useState, useEffect, useCallback } from 'react';
import {
  Users,
  UserPlus,
  Search,
  Lock,
  Unlock,
  Ban,
  CheckCircle2,
  AlertCircle,
  KeyRound,
  RefreshCw,
  Building,
  Edit2,
  Trash2,
  X,
  Eye,
  EyeOff,
  FolderTree,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { PageHeader } from '../components/ui/PageHeader';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';

export interface RoleItem {
  id: number;
  code: string;
  name: string;
  description: string;
}

export interface DepartmentItem {
  id: number;
  code: string;
  name: string;
  description: string;
}

export interface UserAccount {
  id: number;
  username: string;
  email: string;
  fullName: string;
  roleId: number;
  role: string;
  roleName: string;
  departmentId: number | null;
  departmentName: string | null;
  departmentCode: string | null;
  mustChangePassword: boolean;
  failedAttempts: number;
  isLocked: boolean;
  lockedAt: string | null;
  isSuspended: boolean;
  suspendedAt: string | null;
  isDeactivated: boolean;
  deactivatedAt: string | null;
  createdBy: string | null;
  createdAt: string;
  updatedAt: string;
}

export const UserManagementView: React.FC = () => {
  const { user, csrfToken, openLoginModal } = useAuth();

  const isSuperAdmin = user?.role === 'SUPER_ADMIN';
  const isPrincipal = user?.role === 'PRINCIPAL';
  const isSecretary = user?.role === 'SECRETARY';
  const canManageAccounts = isSuperAdmin || isPrincipal || isSecretary;

  const [activeTab, setActiveTab] = useState<'directory' | 'create' | 'departments'>('directory');

  // Accounts List State
  const [accounts, setAccounts] = useState<UserAccount[]>([]);
  const [roles, setRoles] = useState<RoleItem[]>([]);
  const [departments, setDepartments] = useState<DepartmentItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalAccounts, setTotalAccounts] = useState(0);
  const [isLoadingAccounts, setIsLoadingAccounts] = useState(false);

  // Notification Banner
  const [bannerNotice, setBannerNotice] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Create User Form State
  const [createForm, setCreateForm] = useState({
    username: '',
    email: '',
    fullName: '',
    roleId: '',
    departmentId: '',
    initialPassword: '',
    confirmPassword: '',
  });
  const [showCreatePassword, setShowCreatePassword] = useState(false);
  const [isCreatingUser, setIsCreatingUser] = useState(false);

  // Edit User Modal State
  const [editingUser, setEditingUser] = useState<UserAccount | null>(null);
  const [editForm, setEditForm] = useState({
    fullName: '',
    email: '',
    roleId: '',
    departmentId: '',
  });
  const [isSavingEdit, setIsSavingEdit] = useState(false);

  // Reset Password Modal State
  const [resetTargetUser, setResetTargetUser] = useState<UserAccount | null>(null);
  const [resetForm, setResetForm] = useState({
    temporaryPassword: '',
    confirmPassword: '',
  });
  const [showResetPassword, setShowResetPassword] = useState(false);
  const [isResettingPassword, setIsResettingPassword] = useState(false);

  // Action Confirmation Dialog State (suspend, reactivate, deactivate, unlock)
  const [confirmDialog, setConfirmDialog] = useState<{
    type: 'suspend' | 'reactivate' | 'deactivate' | 'unlock';
    user: UserAccount;
  } | null>(null);
  const [isProcessingAction, setIsProcessingAction] = useState(false);

  // Department Management State (Super Admin)
  const [isCreatingDept, setIsCreatingDept] = useState(false);
  const [newDeptForm, setNewDeptForm] = useState({ code: '', name: '', description: '' });
  const [editingDept, setEditingDept] = useState<DepartmentItem | null>(null);
  const [editDeptForm, setEditDeptForm] = useState({ name: '', description: '' });
  const [isDeptSubmitting, setIsDeptSubmitting] = useState(false);

  // Fetch Roles
  const fetchRoles = useCallback(async () => {
    try {
      const res = await fetch('/api/users/roles');
      if (res.ok) {
        const data = await res.json();
        setRoles(data.roles || []);
      }
    } catch {
      // Handle silently
    }
  }, []);

  // Fetch Departments
  const fetchDepartments = useCallback(async () => {
    try {
      const res = await fetch('/api/users/departments');
      if (res.ok) {
        const data = await res.json();
        setDepartments(data.departments || []);
      }
    } catch {
      // Handle silently
    }
  }, []);

  // Fetch Accounts Directory
  const fetchAccounts = useCallback(async () => {
    if (!canManageAccounts) return;
    setIsLoadingAccounts(true);
    try {
      const params = new URLSearchParams({
        page: String(currentPage),
        limit: '15',
        search: searchQuery,
        role: roleFilter,
        status: statusFilter,
      });
      const res = await fetch(`/api/users?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setAccounts(data.users || []);
        setTotalPages(data.pagination.totalPages || 1);
        setTotalAccounts(data.pagination.total || 0);
      }
    } catch {
      // Handle silently
    } finally {
      setIsLoadingAccounts(false);
    }
  }, [canManageAccounts, currentPage, searchQuery, roleFilter, statusFilter]);

  useEffect(() => {
    if (user && canManageAccounts) {
      fetchRoles();
      fetchDepartments();
    }
  }, [user, canManageAccounts, fetchRoles, fetchDepartments]);

  useEffect(() => {
    if (canManageAccounts && activeTab === 'directory') {
      fetchAccounts();
    }
  }, [canManageAccounts, activeTab, fetchAccounts]);

  // Execute Account Action (Suspend, Reactivate, Deactivate, Unlock)
  const handleExecuteAction = async () => {
    if (!confirmDialog) return;
    setIsProcessingAction(true);
    setBannerNotice(null);

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}),
    };

    try {
      const { type, user: target } = confirmDialog;
      const res = await fetch(`/api/users/${target.id}/${type}`, {
        method: 'PATCH',
        headers,
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || `Failed to execute ${type} action`);
      }

      setBannerNotice({ type: 'success', message: data.message });
      setConfirmDialog(null);
      fetchAccounts();
    } catch (err) {
      setBannerNotice({ type: 'error', message: (err as Error).message });
    } finally {
      setIsProcessingAction(false);
    }
  };

  // Handle Create Account Submission
  const handleCreateAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setBannerNotice(null);

    if (createForm.initialPassword.length < 8) {
      setBannerNotice({ type: 'error', message: 'Temporary password must be at least 8 characters long.' });
      return;
    }

    if (createForm.initialPassword !== createForm.confirmPassword) {
      setBannerNotice({ type: 'error', message: 'Initial password and confirmation password do not match.' });
      return;
    }

    setIsCreatingUser(true);
    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}),
        },
        body: JSON.stringify(createForm),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to create account');
      }

      setBannerNotice({
        type: 'success',
        message: data.message || `Account created successfully for ${data.user?.fullName}.`,
      });

      setCreateForm({
        username: '',
        email: '',
        fullName: '',
        roleId: '',
        departmentId: '',
        initialPassword: '',
        confirmPassword: '',
      });

      setActiveTab('directory');
      fetchAccounts();
    } catch (err) {
      setBannerNotice({ type: 'error', message: (err as Error).message });
    } finally {
      setIsCreatingUser(false);
    }
  };

  // Handle Edit Account Submission
  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setIsSavingEdit(true);
    setBannerNotice(null);

    try {
      const res = await fetch(`/api/users/${editingUser.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}),
        },
        body: JSON.stringify(editForm),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to update account details');
      }

      setBannerNotice({ type: 'success', message: data.message });
      setEditingUser(null);
      fetchAccounts();
    } catch (err) {
      setBannerNotice({ type: 'error', message: (err as Error).message });
    } finally {
      setIsSavingEdit(false);
    }
  };

  // Handle Password Reset Submission
  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!resetTargetUser) return;
    setBannerNotice(null);

    if (resetForm.temporaryPassword.length < 8) {
      setBannerNotice({ type: 'error', message: 'Temporary password must be at least 8 characters long.' });
      return;
    }

    if (resetForm.temporaryPassword !== resetForm.confirmPassword) {
      setBannerNotice({ type: 'error', message: 'Temporary password and confirmation password do not match.' });
      return;
    }

    setIsResettingPassword(true);
    try {
      const res = await fetch(`/api/users/${resetTargetUser.id}/reset-password`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}),
        },
        body: JSON.stringify(resetForm),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to reset user password');
      }

      setBannerNotice({ type: 'success', message: data.message });
      setResetTargetUser(null);
      setResetForm({ temporaryPassword: '', confirmPassword: '' });
      fetchAccounts();
    } catch (err) {
      setBannerNotice({ type: 'error', message: (err as Error).message });
    } finally {
      setIsResettingPassword(false);
    }
  };

  // Handle Create Department (Super Admin)
  const handleCreateDepartment = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsDeptSubmitting(true);
    setBannerNotice(null);

    try {
      const res = await fetch('/api/users/departments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}),
        },
        body: JSON.stringify(newDeptForm),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create department');

      setBannerNotice({ type: 'success', message: `Department '${data.department.name}' created successfully.` });
      setIsCreatingDept(false);
      setNewDeptForm({ code: '', name: '', description: '' });
      fetchDepartments();
    } catch (err) {
      setBannerNotice({ type: 'error', message: (err as Error).message });
    } finally {
      setIsDeptSubmitting(false);
    }
  };

  // Handle Edit Department (Super Admin)
  const handleUpdateDepartment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDept) return;
    setIsDeptSubmitting(true);
    setBannerNotice(null);

    try {
      const res = await fetch(`/api/users/departments/${editingDept.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...(csrfToken ? { 'X-CSRF-Token': csrfToken } : {}),
        },
        body: JSON.stringify(editDeptForm),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to update department');

      setBannerNotice({ type: 'success', message: `Department '${data.department.name}' updated successfully.` });
      setEditingDept(null);
      fetchDepartments();
    } catch (err) {
      setBannerNotice({ type: 'error', message: (err as Error).message });
    } finally {
      setIsDeptSubmitting(false);
    }
  };

  // Guard for non-logged in or unauthorized roles (clean fallback)
  if (!user || !canManageAccounts) {
    return (
      <div className="space-y-4">
        <PageHeader title="User Management" />
        <Card>
          <CardContent className="p-6 text-center text-xs text-stone-600 space-y-3">
            <p>Please sign in with authorized administrative credentials to access User Management.</p>
            <Button variant="primary" size="sm" onClick={openLoginModal}>
              Sign In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Selected role in create form
  const selectedCreateRole = roles.find((r) => String(r.id) === String(createForm.roleId));
  const isCreateDeptRole = selectedCreateRole && ['DEPARTMENT', 'HOD'].includes(selectedCreateRole.code);

  const selectedEditRole = roles.find((r) => String(r.id) === String(editForm.roleId));
  const isEditDeptRole = selectedEditRole && ['DEPARTMENT', 'HOD'].includes(selectedEditRole.code);

  return (
    <div className="space-y-5">
      {/* Top Banner Notice */}
      {bannerNotice && (
        <div
          className={`p-3.5 rounded-lg text-xs flex items-start justify-between gap-3 ${
            bannerNotice.type === 'success'
              ? 'bg-emerald-50 border border-emerald-200 text-emerald-900'
              : 'bg-rose-50 border border-rose-200 text-rose-900'
          }`}
          role="alert"
        >
          <div className="flex items-start gap-2 min-w-0">
            {bannerNotice.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            )}
            <span className="font-medium leading-relaxed">{bannerNotice.message}</span>
          </div>
          <button
            type="button"
            onClick={() => setBannerNotice(null)}
            className="text-stone-400 hover:text-stone-700 p-0.5 rounded cursor-pointer"
            aria-label="Dismiss message"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Page Header */}
      <PageHeader
        title="User Management"
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant={activeTab === 'create' ? 'gold' : 'outline'}
              size="sm"
              icon={<UserPlus className="w-3.5 h-3.5" />}
              onClick={() => {
                setBannerNotice(null);
                setActiveTab('create');
              }}
            >
              Configure New User
            </Button>
            {isSuperAdmin && (
              <Button
                variant={activeTab === 'departments' ? 'gold' : 'outline'}
                size="sm"
                icon={<Building className="w-3.5 h-3.5" />}
                onClick={() => {
                  setBannerNotice(null);
                  setActiveTab('departments');
                }}
              >
                Department Accounts
              </Button>
            )}
          </div>
        }
      />

      {/* Tabs Bar */}
      <div className="flex items-center gap-1.5 border-b border-stone-200 pb-2 text-xs overflow-x-auto no-scrollbar">
        <button
          type="button"
          onClick={() => {
            setBannerNotice(null);
            setActiveTab('directory');
          }}
          className={`px-3.5 py-2 rounded-lg font-medium transition-all min-h-[38px] whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeTab === 'directory'
              ? 'bg-[#4B2E2E] text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Institutional Directory ({totalAccounts})</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setBannerNotice(null);
            setActiveTab('create');
          }}
          className={`px-3.5 py-2 rounded-lg font-medium transition-all min-h-[38px] whitespace-nowrap cursor-pointer flex items-center gap-2 ${
            activeTab === 'create'
              ? 'bg-[#4B2E2E] text-white shadow-xs'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <UserPlus className="w-3.5 h-3.5" />
          <span>Provision User Account</span>
        </button>

        {isSuperAdmin && (
          <button
            type="button"
            onClick={() => {
              setBannerNotice(null);
              setActiveTab('departments');
            }}
            className={`px-3.5 py-2 rounded-lg font-medium transition-all min-h-[38px] whitespace-nowrap cursor-pointer flex items-center gap-2 ${
              activeTab === 'departments'
                ? 'bg-[#4B2E2E] text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
            }`}
          >
            <FolderTree className="w-3.5 h-3.5" />
            <span>Departments ({departments.length})</span>
          </button>
        )}
      </div>

      {/* TAB 1: ACCOUNTS DIRECTORY */}
      {activeTab === 'directory' && (
        <div className="space-y-4">
          {/* Search & Filter Toolbar */}
          <Card>
            <CardContent className="p-3.5">
              <div className="flex flex-col md:flex-row items-center gap-3 justify-between">
                {/* Search Field */}
                <div className="relative w-full md:w-80">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-400">
                    <Search className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    placeholder="Search by name, username, email..."
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] focus:border-[#4B2E2E] transition-all min-h-[38px]"
                  />
                </div>

                {/* Filters */}
                <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
                  <select
                    value={roleFilter}
                    onChange={(e) => {
                      setRoleFilter(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="flex-1 sm:flex-none py-2 px-3 text-xs bg-white border border-stone-300 rounded-lg text-stone-700 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px]"
                  >
                    <option value="ALL">All Roles</option>
                    {roles.map((r) => (
                      <option key={r.code} value={r.code}>
                        {r.name}
                      </option>
                    ))}
                  </select>

                  <select
                    value={statusFilter}
                    onChange={(e) => {
                      setStatusFilter(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="flex-1 sm:flex-none py-2 px-3 text-xs bg-white border border-stone-300 rounded-lg text-stone-700 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px]"
                  >
                    <option value="ALL">All Statuses</option>
                    <option value="ACTIVE">Active</option>
                    <option value="LOCKED">Temporarily Locked</option>
                    <option value="SUSPENDED">Suspended</option>
                    <option value="DEACTIVATED">Deactivated</option>
                  </select>

                  <button
                    type="button"
                    onClick={fetchAccounts}
                    title="Refresh List"
                    className="min-h-[38px] min-w-[38px] flex items-center justify-center p-2 border border-stone-300 rounded-lg hover:bg-stone-100 text-stone-600 transition-all cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoadingAccounts ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Directory Content */}
          <Card>
            {/* Desktop Table */}
            <div className="hidden md:block overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-[#FAF9F5] border-b border-stone-200 text-stone-700 font-semibold text-[11px] uppercase tracking-wider">
                    <th className="py-3 px-4">Account User</th>
                    <th className="py-3 px-4">Role &amp; Department</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Created Details</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-200">
                  {isLoadingAccounts ? (
                    <tr>
                      <td colSpan={5} className="py-10 text-center text-stone-500">
                        <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-[#D4AF37]" />
                        <span>Loading institutional accounts...</span>
                      </td>
                    </tr>
                  ) : accounts.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-10 text-center text-stone-500">
                        No accounts found matching the current search and filter criteria.
                      </td>
                    </tr>
                  ) : (
                    accounts.map((acc) => {
                      const isTargetSuperAdmin = acc.role === 'SUPER_ADMIN';
                      const isSelf = acc.id === user?.id;

                      return (
                        <tr key={acc.id} className="hover:bg-stone-50/80 transition-colors">
                          {/* User Identity */}
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2.5">
                              <div className="w-8 h-8 rounded-full bg-[#4B2E2E] text-[#F5F5DC] flex items-center justify-center font-bold text-xs shrink-0">
                                {acc.fullName.charAt(0).toUpperCase()}
                              </div>
                              <div className="min-w-0">
                                <span className="font-semibold text-stone-900 block leading-tight truncate">
                                  {acc.fullName}
                                  {isSelf && (
                                    <span className="ml-1.5 text-[10px] text-stone-500 font-normal">
                                      (You)
                                    </span>
                                  )}
                                </span>
                                <span className="text-[11px] text-stone-500 font-mono block truncate">
                                  {acc.username} · {acc.email}
                                </span>
                              </div>
                            </div>
                          </td>

                          {/* Role & Department */}
                          <td className="py-3 px-4">
                            <div className="space-y-1">
                              <Badge variant={isTargetSuperAdmin ? 'gold' : 'institutional'} size="sm">
                                {acc.roleName}
                              </Badge>
                              {acc.departmentName && (
                                <div className="text-[11px] text-stone-600 flex items-center gap-1">
                                  <Building className="w-3 h-3 text-stone-400 shrink-0" />
                                  <span className="truncate">{acc.departmentName}</span>
                                </div>
                              )}
                            </div>
                          </td>

                          {/* Status */}
                          <td className="py-3 px-4">
                            <div className="flex flex-wrap items-center gap-1.5">
                              {acc.isDeactivated ? (
                                <Badge variant="warning" size="sm">
                                  <Trash2 className="w-3 h-3 mr-1" />
                                  Deactivated
                                </Badge>
                              ) : acc.isLocked ? (
                                <Badge variant="warning" size="sm">
                                  <Lock className="w-3 h-3 mr-1" />
                                  Locked ({acc.failedAttempts} fails)
                                </Badge>
                              ) : acc.isSuspended ? (
                                <Badge variant="warning" size="sm">
                                  <Ban className="w-3 h-3 mr-1" />
                                  Suspended
                                </Badge>
                              ) : (
                                <Badge variant="success" size="sm">
                                  <CheckCircle2 className="w-3 h-3 mr-1" />
                                  Active
                                </Badge>
                              )}

                              {acc.mustChangePassword && (
                                <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 font-medium">
                                  Pwd Change Req
                                </span>
                              )}
                            </div>
                          </td>

                          {/* Created Details */}
                          <td className="py-3 px-4 text-stone-500 text-[11px] tabular-nums">
                            <span>{new Date(acc.createdAt).toLocaleDateString()}</span>
                            {acc.createdBy && (
                              <span className="block text-stone-400 text-[10px]">
                                by {acc.createdBy}
                              </span>
                            )}
                          </td>

                          {/* Action Buttons */}
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {/* Edit Account */}
                              {(!isTargetSuperAdmin || isSuperAdmin) && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingUser(acc);
                                    setEditForm({
                                      fullName: acc.fullName,
                                      email: acc.email,
                                      roleId: String(acc.roleId),
                                      departmentId: acc.departmentId ? String(acc.departmentId) : '',
                                    });
                                  }}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded text-stone-700 bg-stone-100 hover:bg-stone-200 border border-stone-200 transition-colors cursor-pointer min-h-[32px]"
                                  title="Edit full name, email, role, or department"
                                >
                                  <Edit2 className="w-3 h-3" />
                                  <span>Edit</span>
                                </button>
                              )}

                              {/* Reset Password */}
                              {(!isTargetSuperAdmin || isSuperAdmin) && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setResetTargetUser(acc);
                                    setResetForm({ temporaryPassword: '', confirmPassword: '' });
                                  }}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-200 transition-colors cursor-pointer min-h-[32px]"
                                  title="Set temporary password and force password change"
                                >
                                  <KeyRound className="w-3 h-3 text-amber-700" />
                                  <span>Reset Pwd</span>
                                </button>
                              )}

                              {/* Unlock */}
                              {acc.isLocked && (
                                <button
                                  type="button"
                                  onClick={() => setConfirmDialog({ type: 'unlock', user: acc })}
                                  className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition-colors cursor-pointer min-h-[32px]"
                                  title="Reset failed login counter and unlock account"
                                >
                                  <Unlock className="w-3 h-3" />
                                  <span>Unlock</span>
                                </button>
                              )}

                              {/* Suspend / Reactivate */}
                              {!isSelf && (!isTargetSuperAdmin || isSuperAdmin) && (
                                <>
                                  {acc.isSuspended || acc.isDeactivated ? (
                                    <button
                                      type="button"
                                      onClick={() => setConfirmDialog({ type: 'reactivate', user: acc })}
                                      className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition-colors cursor-pointer min-h-[32px]"
                                      title="Reactivate account"
                                    >
                                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                      <span>Reactivate</span>
                                    </button>
                                  ) : (
                                    <button
                                      type="button"
                                      onClick={() => setConfirmDialog({ type: 'suspend', user: acc })}
                                      className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded text-rose-800 bg-rose-50 hover:bg-rose-100 border border-rose-200 transition-colors cursor-pointer min-h-[32px]"
                                      title="Suspend account and terminate active sessions"
                                    >
                                      <Ban className="w-3 h-3" />
                                      <span>Suspend</span>
                                    </button>
                                  )}
                                </>
                              )}

                              {/* Deactivate */}
                              {!isSelf && !acc.isDeactivated && (!isTargetSuperAdmin || isSuperAdmin) && (
                                <button
                                  type="button"
                                  onClick={() => setConfirmDialog({ type: 'deactivate', user: acc })}
                                  className="inline-flex items-center gap-1 px-2 py-1 text-xs font-medium rounded text-stone-500 hover:text-stone-800 hover:bg-stone-100 border border-transparent transition-colors cursor-pointer min-h-[32px]"
                                  title="Deactivate account while preserving historical records"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards View */}
            <div className="block md:hidden divide-y divide-stone-200">
              {isLoadingAccounts ? (
                <div className="py-10 text-center text-stone-500">
                  <RefreshCw className="w-5 h-5 animate-spin mx-auto mb-2 text-[#D4AF37]" />
                  <span>Loading accounts...</span>
                </div>
              ) : accounts.length === 0 ? (
                <div className="py-10 text-center text-stone-500 text-xs p-4">
                  No accounts found matching criteria.
                </div>
              ) : (
                accounts.map((acc) => {
                  const isTargetSuperAdmin = acc.role === 'SUPER_ADMIN';
                  const isSelf = acc.id === user?.id;

                  return (
                    <div key={acc.id} className="p-3.5 space-y-2.5 bg-white">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <div className="w-8 h-8 rounded-full bg-[#4B2E2E] text-[#F5F5DC] flex items-center justify-center font-bold text-xs shrink-0">
                            {acc.fullName.charAt(0).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <span className="font-semibold text-stone-900 block leading-tight text-xs truncate">
                              {acc.fullName}
                              {isSelf && <span className="ml-1 text-[10px] text-stone-500">(You)</span>}
                            </span>
                            <span className="text-[11px] text-stone-500 font-mono block truncate">
                              {acc.username} · {acc.email}
                            </span>
                          </div>
                        </div>
                        <Badge variant={isTargetSuperAdmin ? 'gold' : 'institutional'} size="sm">
                          {acc.roleName}
                        </Badge>
                      </div>

                      {acc.departmentName && (
                        <div className="text-[11px] text-stone-600 flex items-center gap-1.5 pl-10">
                          <Building className="w-3 h-3 text-stone-400" />
                          <span>{acc.departmentName}</span>
                        </div>
                      )}

                      <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-stone-100">
                        <div className="flex flex-wrap items-center gap-1.5">
                          {acc.isDeactivated ? (
                            <Badge variant="warning" size="sm">
                              Deactivated
                            </Badge>
                          ) : acc.isLocked ? (
                            <Badge variant="warning" size="sm">
                              Locked
                            </Badge>
                          ) : acc.isSuspended ? (
                            <Badge variant="warning" size="sm">
                              Suspended
                            </Badge>
                          ) : (
                            <Badge variant="success" size="sm">
                              Active
                            </Badge>
                          )}

                          {acc.mustChangePassword && (
                            <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-800">
                              Pwd Change Req
                            </span>
                          )}
                        </div>

                        <span className="text-[11px] text-stone-400 tabular-nums">
                          {new Date(acc.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      {/* Mobile Actions Toolbar */}
                      <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-stone-100">
                        {(!isTargetSuperAdmin || isSuperAdmin) && (
                          <button
                            type="button"
                            onClick={() => {
                              setEditingUser(acc);
                              setEditForm({
                                fullName: acc.fullName,
                                email: acc.email,
                                roleId: String(acc.roleId),
                                departmentId: acc.departmentId ? String(acc.departmentId) : '',
                              });
                            }}
                            className="flex-1 py-1 px-2 text-xs font-medium bg-stone-100 hover:bg-stone-200 rounded text-stone-700 text-center min-h-[34px] flex items-center justify-center gap-1"
                          >
                            <Edit2 className="w-3 h-3" />
                            <span>Edit</span>
                          </button>
                        )}

                        {(!isTargetSuperAdmin || isSuperAdmin) && (
                          <button
                            type="button"
                            onClick={() => {
                              setResetTargetUser(acc);
                              setResetForm({ temporaryPassword: '', confirmPassword: '' });
                            }}
                            className="flex-1 py-1 px-2 text-xs font-medium bg-amber-50 hover:bg-amber-100 rounded text-amber-900 border border-amber-200 text-center min-h-[34px] flex items-center justify-center gap-1"
                          >
                            <KeyRound className="w-3 h-3" />
                            <span>Reset Pwd</span>
                          </button>
                        )}

                        {acc.isLocked && (
                          <button
                            type="button"
                            onClick={() => setConfirmDialog({ type: 'unlock', user: acc })}
                            className="flex-1 py-1 px-2 text-xs font-medium bg-emerald-50 rounded text-emerald-800 border border-emerald-200 min-h-[34px] flex items-center justify-center gap-1"
                          >
                            <Unlock className="w-3 h-3" />
                            <span>Unlock</span>
                          </button>
                        )}

                        {!isSelf && (!isTargetSuperAdmin || isSuperAdmin) && (
                          <>
                            {acc.isSuspended || acc.isDeactivated ? (
                              <button
                                type="button"
                                onClick={() => setConfirmDialog({ type: 'reactivate', user: acc })}
                                className="flex-1 py-1 px-2 text-xs font-medium bg-emerald-50 rounded text-emerald-800 border border-emerald-200 min-h-[34px] flex items-center justify-center gap-1"
                              >
                                <span>Reactivate</span>
                              </button>
                            ) : (
                              <button
                                type="button"
                                onClick={() => setConfirmDialog({ type: 'suspend', user: acc })}
                                className="flex-1 py-1 px-2 text-xs font-medium bg-rose-50 rounded text-rose-800 border border-rose-200 min-h-[34px] flex items-center justify-center gap-1"
                              >
                                <span>Suspend</span>
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Pagination Controls */}
            {totalPages > 1 && (
              <div className="p-3 bg-[#FAF9F5] border-t border-stone-200 flex items-center justify-between text-xs text-stone-600">
                <span className="tabular-nums">
                  Page {currentPage} of {totalPages} ({totalAccounts} total accounts)
                </span>
                <div className="flex items-center gap-1.5">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={currentPage <= 1}
                    onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={currentPage >= totalPages}
                    onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                  >
                    Next
                  </Button>
                </div>
              </div>
            )}
          </Card>
        </div>
      )}

      {/* TAB 2: PROVISION USER ACCOUNT */}
      {activeTab === 'create' && (
        <div className="max-w-2xl mx-auto space-y-4">
          <Card accentTop>
            <CardHeader>
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-[#D4AF37]" />
                <CardTitle>Configure Institutional Account</CardTitle>
              </div>
              <CardDescription>
                Direct account creation for institutional roles. An initial temporary password is set by the creator, and the user must change it at first login.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateAccount} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Full Name */}
                  <div className="md:col-span-2">
                    <label className="block text-xs font-semibold text-stone-800 mb-1">
                      Full Legal / Staff Name <span className="text-rose-700">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Dr. Rajesh Sharma, MD (Ayu)"
                      value={createForm.fullName}
                      onChange={(e) => setCreateForm({ ...createForm, fullName: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px]"
                    />
                  </div>

                  {/* Username */}
                  <div>
                    <label className="block text-xs font-semibold text-stone-800 mb-1">
                      Username <span className="text-rose-700">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. rsharma"
                      value={createForm.username}
                      onChange={(e) => setCreateForm({ ...createForm, username: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px]"
                    />
                  </div>

                  {/* Email */}
                  <div>
                    <label className="block text-xs font-semibold text-stone-800 mb-1">
                      Institutional Email <span className="text-rose-700">*</span>
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. rsharma@kamch.ac.in"
                      value={createForm.email}
                      onChange={(e) => setCreateForm({ ...createForm, email: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px]"
                    />
                  </div>

                  {/* Institutional Role */}
                  <div className={isCreateDeptRole ? 'md:col-span-1' : 'md:col-span-2'}>
                    <label className="block text-xs font-semibold text-stone-800 mb-1">
                      Institutional Role <span className="text-rose-700">*</span>
                    </label>
                    <select
                      required
                      value={createForm.roleId}
                      onChange={(e) => setCreateForm({ ...createForm, roleId: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px]"
                    >
                      <option value="">Select an institutional role...</option>
                      {roles.map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.name} ({r.code})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Department Assignment (Conditional on Role) */}
                  {isCreateDeptRole && (
                    <div className="md:col-span-1">
                      <label className="block text-xs font-semibold text-stone-800 mb-1">
                        Assigned Department <span className="text-rose-700">*</span>
                      </label>
                      <select
                        required
                        value={createForm.departmentId}
                        onChange={(e) => setCreateForm({ ...createForm, departmentId: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px]"
                      >
                        <option value="">Select Ayurvedic Department...</option>
                        {departments.map((d) => (
                          <option key={d.id} value={d.id}>
                            {d.name} ({d.code})
                          </option>
                        ))}
                      </select>
                    </div>
                  )}

                  {/* Initial Temporary Password */}
                  <div>
                    <label className="block text-xs font-semibold text-stone-800 mb-1">
                      Initial Temporary Password <span className="text-rose-700">*</span>
                    </label>
                    <div className="relative">
                      <input
                        type={showCreatePassword ? 'text' : 'password'}
                        required
                        minLength={8}
                        placeholder="Minimum 8 characters"
                        value={createForm.initialPassword}
                        onChange={(e) => setCreateForm({ ...createForm, initialPassword: e.target.value })}
                        className="w-full px-3 pr-10 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px]"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCreatePassword(!showCreatePassword)}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center text-stone-400 hover:text-stone-600 cursor-pointer"
                        aria-label="Toggle password visibility"
                      >
                        {showCreatePassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  {/* Confirm Initial Password */}
                  <div>
                    <label className="block text-xs font-semibold text-stone-800 mb-1">
                      Confirm Temporary Password <span className="text-rose-700">*</span>
                    </label>
                    <input
                      type={showCreatePassword ? 'text' : 'password'}
                      required
                      minLength={8}
                      placeholder="Re-enter password"
                      value={createForm.confirmPassword}
                      onChange={(e) => setCreateForm({ ...createForm, confirmPassword: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px]"
                    />
                  </div>
                </div>

                <div className="p-3 bg-amber-50/60 border border-amber-200/60 rounded-lg text-xs text-amber-900 flex items-start gap-2">
                  <KeyRound className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <span>
                    The user will be required to change this temporary password immediately after their first successful sign in.
                  </span>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-200">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setActiveTab('directory')}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    variant="primary"
                    size="sm"
                    isLoading={isCreatingUser}
                    icon={<UserPlus className="w-3.5 h-3.5" />}
                  >
                    Save &amp; Activate Account
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}

      {/* TAB 3: DEPARTMENTS MANAGEMENT (Super Admin Only) */}
      {activeTab === 'departments' && isSuperAdmin && (
        <div className="space-y-4">
          <Card>
            <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <CardTitle>Ayurvedic Medical College Departments</CardTitle>
                <CardDescription>
                  Configure academic and clinical departments and manage shared departmental accounts.
                </CardDescription>
              </div>
              <Button
                variant="gold"
                size="sm"
                icon={<Building className="w-3.5 h-3.5" />}
                onClick={() => {
                  setNewDeptForm({ code: '', name: '', description: '' });
                  setIsCreatingDept(true);
                }}
              >
                Add Department
              </Button>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-[#FAF9F5] border-b border-stone-200 text-stone-700 font-semibold text-[11px] uppercase tracking-wider">
                      <th className="py-3 px-4">Code</th>
                      <th className="py-3 px-4">Department Name</th>
                      <th className="py-3 px-4">Description</th>
                      <th className="py-3 px-4">Assigned Account</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-200">
                    {departments.map((dept) => {
                      const assignedUser = accounts.find((a) => a.departmentId === dept.id);

                      return (
                        <tr key={dept.id} className="hover:bg-stone-50 transition-colors">
                          <td className="py-3 px-4 font-mono font-semibold text-[#4B2E2E]">
                            {dept.code}
                          </td>
                          <td className="py-3 px-4 font-medium text-stone-900">
                            {dept.name}
                          </td>
                          <td className="py-3 px-4 text-stone-500">
                            {dept.description || '—'}
                          </td>
                          <td className="py-3 px-4">
                            {assignedUser ? (
                              <span className="inline-flex items-center gap-1 font-mono text-stone-800 bg-stone-100 px-2 py-0.5 rounded text-[11px]">
                                {assignedUser.username}
                              </span>
                            ) : (
                              <span className="text-stone-400 italic text-[11px]">Unassigned</span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-right">
                            <button
                              type="button"
                              onClick={() => {
                                setEditingDept(dept);
                                setEditDeptForm({ name: dept.name, description: dept.description });
                              }}
                              className="px-2.5 py-1 text-xs font-medium text-stone-700 bg-stone-100 hover:bg-stone-200 rounded border border-stone-200 cursor-pointer"
                            >
                              Edit
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* MODAL 1: EDIT USER ACCOUNT DETAILS */}
      {editingUser && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative w-full max-w-lg bg-white rounded-xl border border-stone-200 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
            <div className="p-4 sm:p-5 bg-[#FAF9F5] border-b border-stone-200 flex items-center justify-between">
              <div>
                <h3 className="font-serif text-base font-bold text-stone-900">Edit Account Details</h3>
                <p className="text-xs text-stone-500">Modify details for {editingUser.username}</p>
              </div>
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="text-stone-400 hover:text-stone-700 p-1 rounded cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <label className="block text-xs font-semibold text-stone-800 mb-1">Full Name</label>
                <input
                  type="text"
                  required
                  value={editForm.fullName}
                  onChange={(e) => setEditForm({ ...editForm, fullName: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-800 mb-1">Institutional Email</label>
                <input
                  type="email"
                  required
                  value={editForm.email}
                  onChange={(e) => setEditForm({ ...editForm, email: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-800 mb-1">Institutional Role</label>
                <select
                  required
                  value={editForm.roleId}
                  disabled={editingUser.id === user.id}
                  onChange={(e) => setEditForm({ ...editForm, roleId: e.target.value })}
                  className={`w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px] ${
                    editingUser.id === user.id ? 'opacity-60 cursor-not-allowed bg-stone-100' : ''
                  }`}
                >
                  {roles.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.name} ({r.code})
                    </option>
                  ))}
                </select>
                {editingUser.id === user.id && (
                  <span className="text-[11px] text-stone-500 mt-1 block">
                    You cannot change your own role to prevent self-lockout.
                  </span>
                )}
              </div>

              {isEditDeptRole && (
                <div>
                  <label className="block text-xs font-semibold text-stone-800 mb-1">Assigned Department</label>
                  <select
                    required
                    value={editForm.departmentId}
                    onChange={(e) => setEditForm({ ...editForm, departmentId: e.target.value })}
                    className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px]"
                  >
                    <option value="">Select Ayurvedic Department...</option>
                    {departments.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.code})
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-200">
                <Button type="button" variant="outline" size="sm" onClick={() => setEditingUser(null)}>
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm" isLoading={isSavingEdit}>
                  Save Changes
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: RESET PASSWORD */}
      {resetTargetUser && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative w-full max-w-md bg-white rounded-xl border border-stone-200 shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col">
            <div className="p-4 sm:p-5 bg-[#FAF9F5] border-b border-stone-200 flex items-center justify-between">
              <div>
                <h3 className="font-serif text-base font-bold text-stone-900">Reset User Password</h3>
                <p className="text-xs text-stone-500">For account: {resetTargetUser.fullName} ({resetTargetUser.username})</p>
              </div>
              <button
                type="button"
                onClick={() => setResetTargetUser(null)}
                className="text-stone-400 hover:text-stone-700 p-1 rounded cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleResetPassword} className="p-4 sm:p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <label className="block text-xs font-semibold text-stone-800 mb-1">
                  New Temporary Password <span className="text-rose-700">*</span>
                </label>
                <div className="relative">
                  <input
                    type={showResetPassword ? 'text' : 'password'}
                    required
                    minLength={8}
                    placeholder="Minimum 8 characters"
                    value={resetForm.temporaryPassword}
                    onChange={(e) => setResetForm({ ...resetForm, temporaryPassword: e.target.value })}
                    className="w-full px-3 pr-10 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowResetPassword(!showResetPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-stone-400 hover:text-stone-600 cursor-pointer"
                  >
                    {showResetPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-800 mb-1">
                  Confirm Temporary Password <span className="text-rose-700">*</span>
                </label>
                <input
                  type={showResetPassword ? 'text' : 'password'}
                  required
                  minLength={8}
                  placeholder="Re-enter password"
                  value={resetForm.confirmPassword}
                  onChange={(e) => setResetForm({ ...resetForm, confirmPassword: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-[#D4AF37] min-h-[38px]"
                />
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 space-y-1">
                <p className="font-semibold">Security Enforcement:</p>
                <ul className="list-disc list-inside space-y-0.5 text-[11px] text-amber-800">
                  <li>Target user will be forced to change this password on their next sign in.</li>
                  <li>All existing active sessions for this account will be terminated immediately.</li>
                </ul>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-200">
                <Button type="button" variant="outline" size="sm" onClick={() => setResetTargetUser(null)}>
                  Cancel
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="sm"
                  isLoading={isResettingPassword}
                  icon={<KeyRound className="w-3.5 h-3.5" />}
                >
                  Apply Password Reset
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 3: CONFIRM ACTION (Suspend, Reactivate, Deactivate, Unlock) */}
      {confirmDialog && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative w-full max-w-md bg-white rounded-xl border border-stone-200 shadow-2xl overflow-hidden my-auto p-5 space-y-4">
            <div className="flex items-start gap-3">
              <div
                className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                  confirmDialog.type === 'deactivate' || confirmDialog.type === 'suspend'
                    ? 'bg-rose-100 text-rose-700'
                    : 'bg-emerald-100 text-emerald-700'
                }`}
              >
                {confirmDialog.type === 'deactivate' ? (
                  <Trash2 className="w-5 h-5" />
                ) : confirmDialog.type === 'suspend' ? (
                  <Ban className="w-5 h-5" />
                ) : confirmDialog.type === 'unlock' ? (
                  <Unlock className="w-5 h-5" />
                ) : (
                  <CheckCircle2 className="w-5 h-5" />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <h4 className="font-serif text-sm font-bold text-stone-900 capitalize">
                  {confirmDialog.type === 'deactivate'
                    ? 'Deactivate Account'
                    : confirmDialog.type === 'suspend'
                    ? 'Suspend Account'
                    : confirmDialog.type === 'unlock'
                    ? 'Unlock Account'
                    : 'Reactivate Account'}
                </h4>
                <p className="text-xs text-stone-600 mt-1 leading-relaxed">
                  {confirmDialog.type === 'deactivate' && (
                    <>
                      Are you sure you want to deactivate account <strong>{confirmDialog.user.fullName}</strong> ({confirmDialog.user.username})?
                      This will prevent future logins and terminate active sessions. All historical financial records, fees, and audit history will remain fully intact.
                    </>
                  )}
                  {confirmDialog.type === 'suspend' && (
                    <>
                      Are you sure you want to suspend account <strong>{confirmDialog.user.fullName}</strong> ({confirmDialog.user.username})?
                      This user will be immediately logged out and blocked from logging in until reactivated.
                    </>
                  )}
                  {confirmDialog.type === 'reactivate' && (
                    <>
                      Reactivate account <strong>{confirmDialog.user.fullName}</strong> ({confirmDialog.user.username})?
                      The user will be eligible to sign in again.
                    </>
                  )}
                  {confirmDialog.type === 'unlock' && (
                    <>
                      Unlock account <strong>{confirmDialog.user.fullName}</strong> ({confirmDialog.user.username})?
                      This will reset the consecutive failed login attempts counter from {confirmDialog.user.failedAttempts} to 0.
                    </>
                  )}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-200">
              <Button
                type="button"
                variant="outline"
                size="sm"
                disabled={isProcessingAction}
                onClick={() => setConfirmDialog(null)}
              >
                Cancel
              </Button>
              <Button
                type="button"
                variant={confirmDialog.type === 'deactivate' || confirmDialog.type === 'suspend' ? 'primary' : 'gold'}
                size="sm"
                isLoading={isProcessingAction}
                onClick={handleExecuteAction}
              >
                Confirm {confirmDialog.type}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: CREATE DEPARTMENT (Super Admin) */}
      {isCreatingDept && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative w-full max-w-md bg-white rounded-xl border border-stone-200 shadow-2xl overflow-hidden my-auto p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <h3 className="font-serif text-base font-bold text-stone-900">Add Academic Department</h3>
              <button
                type="button"
                onClick={() => setIsCreatingDept(false)}
                className="text-stone-400 hover:text-stone-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateDepartment} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-stone-800 mb-1">
                  Department Code <span className="text-rose-700">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. SHALYA_TANTRA"
                  value={newDeptForm.code}
                  onChange={(e) => setNewDeptForm({ ...newDeptForm, code: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 uppercase font-mono min-h-[38px]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-800 mb-1">
                  Department Name <span className="text-rose-700">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Department of Shalya Tantra"
                  value={newDeptForm.name}
                  onChange={(e) => setNewDeptForm({ ...newDeptForm, name: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 min-h-[38px]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-800 mb-1">Description</label>
                <textarea
                  rows={2}
                  placeholder="e.g. General Surgery & Para-Surgical Techniques"
                  value={newDeptForm.description}
                  onChange={(e) => setNewDeptForm({ ...newDeptForm, description: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-200">
                <Button type="button" variant="outline" size="sm" onClick={() => setIsCreatingDept(false)}>
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm" isLoading={isDeptSubmitting}>
                  Save Department
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 5: EDIT DEPARTMENT (Super Admin) */}
      {editingDept && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative w-full max-w-md bg-white rounded-xl border border-stone-200 shadow-2xl overflow-hidden my-auto p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <div>
                <h3 className="font-serif text-base font-bold text-stone-900">Edit Department</h3>
                <p className="text-xs font-mono text-[#4B2E2E]">{editingDept.code}</p>
              </div>
              <button
                type="button"
                onClick={() => setEditingDept(null)}
                className="text-stone-400 hover:text-stone-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleUpdateDepartment} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-stone-800 mb-1">Department Name</label>
                <input
                  type="text"
                  required
                  value={editDeptForm.name}
                  onChange={(e) => setEditDeptForm({ ...editDeptForm, name: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900 min-h-[38px]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-800 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={editDeptForm.description}
                  onChange={(e) => setEditDeptForm({ ...editDeptForm, description: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white border border-stone-300 rounded-lg text-stone-900"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-stone-200">
                <Button type="button" variant="outline" size="sm" onClick={() => setEditingDept(null)}>
                  Cancel
                </Button>
                <Button type="submit" variant="primary" size="sm" isLoading={isDeptSubmitting}>
                  Save Changes
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
