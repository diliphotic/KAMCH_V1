import { Pool, PoolConnection } from 'mysql2/promise';
import { MemoryDatabase } from './memory-db.ts';

/**
 * Handles query execution against either MySQL or the in-memory fallback database.
 */
export class HybridQueryHandler {
  private memDb = MemoryDatabase.getInstance();

  async executeQuery(sql: string, params: any[] = []): Promise<[any, any]> {
    const trimmed = sql.trim();
    const upper = trimmed.toUpperCase();

    // 1. Connection check
    if (upper.startsWith('SELECT 1')) {
      return [[{ connected: 1 }], []];
    }

    // 2. Roles queries
    // 2. Roles queries
    if (upper.includes('FROM ROLES') || upper.includes('FROM `ROLES`')) {
      if (upper.startsWith('SELECT ID FROM ROLES WHERE CODE =') || upper.startsWith('SELECT ID FROM `ROLES` WHERE CODE =')) {
        const code = params[0];
        const role = this.memDb.roles.find((r) => r.code === code);
        return [role ? [{ id: role.id }] : [], []];
      }
      if (upper.includes('WHERE ID = ?')) {
        const roleId = Number(params[0]);
        const role = this.memDb.roles.find((r) => r.id === roleId);
        return [role ? [role] : [], []];
      }
      return [[...this.memDb.roles], []];
    }

    // 2b. Departments queries
    if (upper.includes('FROM DEPARTMENTS') || upper.includes('FROM `DEPARTMENTS`')) {
      if (upper.includes('WHERE ID = ?')) {
        const deptId = Number(params[0]);
        const dept = this.memDb.departments.find((d) => d.id === deptId);
        return [dept ? [dept] : [], []];
      }
      if (upper.includes('WHERE CODE = ?')) {
        const code = String(params[0]);
        const dept = this.memDb.departments.find((d) => d.code === code);
        return [dept ? [dept] : [], []];
      }
      return [[...this.memDb.departments], []];
    }

    if (upper.startsWith('INSERT INTO DEPARTMENTS') || upper.startsWith('INSERT INTO `DEPARTMENTS`')) {
      const id = this.memDb.generateId('departments');
      const now = new Date().toISOString();
      this.memDb.departments.push({
        id,
        code: params[0],
        name: params[1],
        description: params[2] || '',
        created_at: now,
        updated_at: now,
      });
      return [{ insertId: id, affectedRows: 1 }, []];
    }

    if (upper.startsWith('UPDATE DEPARTMENTS') || upper.startsWith('UPDATE `DEPARTMENTS`')) {
      const targetId = Number(params[params.length - 1]);
      const dept = this.memDb.departments.find((d) => d.id === targetId);
      if (dept) {
        dept.name = params[0];
        dept.description = params[1] || '';
        dept.updated_at = new Date().toISOString();
        return [{ affectedRows: 1 }, []];
      }
      return [{ affectedRows: 0 }, []];
    }

    // 3. User queries
    if (upper.includes('FROM USERS') || upper.includes('FROM `USERS`')) {
      // Check single user by ID
      if (upper.includes('WHERE U.ID = ?') || (upper.includes('WHERE ID = ?') && !upper.includes('UPDATE USERS'))) {
        const targetId = Number(params[0]);
        const user = this.memDb.users.find((u) => u.id === targetId);
        if (!user) return [[], []];
        const role = this.memDb.roles.find((r) => r.id === user.role_id);
        const dept = user.department_id ? this.memDb.departments.find((d) => d.id === user.department_id) : null;
        return [
          [
            {
              ...user,
              role_code: role?.code || 'OFFICE',
              role_name: role?.name || 'Office Staff',
              department_name: dept?.name || null,
              department_code: dept?.code || null,
            },
          ],
          [],
        ];
      }

      // Check user by username or email (e.g. login or duplicate check)
      if (upper.includes('WHERE U.USERNAME = ? OR U.EMAIL = ?') || upper.includes('WHERE USERNAME = ? OR EMAIL = ?')) {
        const p1 = String(params[0]).toLowerCase();
        const p2 = String(params[1] !== undefined ? params[1] : params[0]).toLowerCase();
        const user = this.memDb.users.find(
          (u) => u.username.toLowerCase() === p1 || u.email.toLowerCase() === p2
        );
        if (!user) return [[], []];
        const role = this.memDb.roles.find((r) => r.id === user.role_id);
        const dept = user.department_id ? this.memDb.departments.find((d) => d.id === user.department_id) : null;
        return [
          [
            {
              ...user,
              role_code: role?.code || 'OFFICE',
              role_name: role?.name || 'Office Staff',
              department_name: dept?.name || null,
              department_code: dept?.code || null,
            },
          ],
          [],
        ];
      }

      if (upper.startsWith('SELECT U.ID,') || upper.startsWith('SELECT U.*') || upper.includes('COUNT(*)')) {
        // Build user list with role and department join
        let list = this.memDb.users.map((u) => {
          const role = this.memDb.roles.find((r) => r.id === u.role_id);
          const dept = u.department_id ? this.memDb.departments.find((d) => d.id === u.department_id) : null;
          const creator = u.created_by ? this.memDb.users.find((c) => c.id === u.created_by) : null;
          return {
            ...u,
            role_code: role?.code || '',
            role_name: role?.name || '',
            department_name: dept?.name || null,
            department_code: dept?.code || null,
            created_by_username: creator?.username || null,
          };
        });

        // Filter out Super Admin if query has r.code != 'SUPER_ADMIN'
        if (upper.includes("R.CODE != 'SUPER_ADMIN'") || upper.includes('R.CODE != ?')) {
          list = list.filter((u) => u.role_code !== 'SUPER_ADMIN');
        }

        // Apply search query if present in params
        const searchParam = params.find((p) => typeof p === 'string' && p.startsWith('%') && p.endsWith('%'));
        if (searchParam) {
          const rawSearch = searchParam.slice(1, -1).toLowerCase();
          list = list.filter(
            (u) =>
              u.username.toLowerCase().includes(rawSearch) ||
              u.email.toLowerCase().includes(rawSearch) ||
              u.full_name.toLowerCase().includes(rawSearch)
          );
        }

        // Apply role filter if present
        const roleFilterParam = params.find(
          (p) => typeof p === 'string' && ['SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY', 'OFFICE', 'STAFF', 'HOD', 'FACULTY', 'LIBRARY', 'DEPARTMENT'].includes(p)
        );
        if (roleFilterParam) {
          list = list.filter((u) => u.role_code === roleFilterParam);
        }

        // Apply status filter if present in query SQL
        if (upper.includes('U.IS_DEACTIVATED = TRUE')) {
          list = list.filter((u) => u.is_deactivated);
        } else if (upper.includes('U.IS_LOCKED = TRUE')) {
          list = list.filter((u) => u.is_locked);
        } else if (upper.includes('U.IS_SUSPENDED = TRUE')) {
          list = list.filter((u) => u.is_suspended && !u.is_deactivated);
        } else if (upper.includes('U.IS_LOCKED = FALSE AND U.IS_SUSPENDED = FALSE AND U.IS_DEACTIVATED = FALSE')) {
          list = list.filter((u) => !u.is_locked && !u.is_suspended && !u.is_deactivated);
        }

        if (upper.includes('COUNT(*)')) {
          return [[{ total: list.length }], []];
        }

        // Sorting by ID DESC
        list.sort((a, b) => b.id - a.id);

        // Pagination limit & offset
        const limitParam = typeof params[params.length - 2] === 'number' ? params[params.length - 2] : 20;
        const offsetParam = typeof params[params.length - 1] === 'number' ? params[params.length - 1] : 0;
        const paged = list.slice(offsetParam, offsetParam + limitParam);

        return [paged, []];
      }

      if (upper.startsWith('INSERT INTO USERS') || upper.startsWith('INSERT INTO `USERS`')) {
        const id = this.memDb.generateId('users');
        const now = new Date().toISOString();
        // Check params mapping:
        // [username, email, password_hash, role_id, department_id, full_name, must_change_password, failed_attempts, is_locked, is_suspended, is_deactivated, created_by]
        // or [cleanUsername, cleanEmail, passwordHash, parsedRoleId, departmentId, cleanFullName, createdBy]
        const newUser: any = {
          id,
          username: params[0],
          email: params[1],
          password_hash: params[2],
          role_id: Number(params[3]),
          department_id: params[4] !== undefined && params[4] !== null ? Number(params[4]) : null,
          full_name: params[5],
          must_change_password: true,
          failed_attempts: 0,
          is_locked: false,
          locked_at: null,
          is_suspended: false,
          suspended_at: null,
          is_deactivated: false,
          deactivated_at: null,
          created_by: params[6] !== undefined ? Number(params[6]) : null,
          created_at: now,
          updated_at: now,
        };
        this.memDb.users.push(newUser);
        return [{ insertId: id, affectedRows: 1 }, []];
      }

      if (upper.startsWith('UPDATE USERS') || upper.startsWith('UPDATE `USERS`')) {
        const targetId = Number(params[params.length - 1]);
        const user = this.memDb.users.find((u) => u.id === targetId);
        if (user) {
          if (upper.includes('FAILED_ATTEMPTS = ?, IS_LOCKED = TRUE')) {
            user.failed_attempts = Number(params[0]);
            user.is_locked = true;
            user.locked_at = new Date().toISOString();
          } else if (upper.includes('FAILED_ATTEMPTS = 0, IS_LOCKED = FALSE')) {
            user.failed_attempts = 0;
            user.is_locked = false;
            user.locked_at = null;
          } else if (upper.includes('IS_LOCKED = FALSE, LOCKED_AT = NULL, FAILED_ATTEMPTS = 0')) {
            user.is_locked = false;
            user.locked_at = null;
            user.failed_attempts = 0;
          } else if (upper.includes('FAILED_ATTEMPTS = ?')) {
            user.failed_attempts = Number(params[0]);
          } else if (upper.includes('FAILED_ATTEMPTS = 0')) {
            user.failed_attempts = 0;
          } else if (upper.includes('PASSWORD_HASH = ?, MUST_CHANGE_PASSWORD = FALSE')) {
            user.password_hash = params[0];
            user.must_change_password = false;
          } else if (upper.includes('PASSWORD_HASH = ?, MUST_CHANGE_PASSWORD = TRUE')) {
            user.password_hash = params[0];
            user.must_change_password = true;
          } else if (upper.includes('IS_SUSPENDED = TRUE')) {
            user.is_suspended = true;
            user.suspended_at = new Date().toISOString();
          } else if (upper.includes('IS_SUSPENDED = FALSE')) {
            user.is_suspended = false;
            user.suspended_at = null;
            user.is_deactivated = false;
            user.deactivated_at = null;
          } else if (upper.includes('IS_DEACTIVATED = TRUE')) {
            user.is_deactivated = true;
            user.deactivated_at = new Date().toISOString();
          } else if (upper.includes('FULL_NAME = ?, EMAIL = ?, ROLE_ID = ?')) {
            user.full_name = params[0];
            user.email = params[1];
            user.role_id = Number(params[2]);
            user.department_id = params[3] !== null && params[3] !== undefined ? Number(params[3]) : null;
          }
          user.updated_at = new Date().toISOString();
          return [{ affectedRows: 1 }, []];
        }
        return [{ affectedRows: 0 }, []];
      }
    }

    // 4. Sessions queries
    if (upper.includes('FROM SESSIONS') || upper.includes('FROM `SESSIONS`')) {
      if (upper.includes('TOKEN_HASH = ?')) {
        const tokenHash = params[0];
        const session = this.memDb.sessions.find((s) => s.token_hash === tokenHash && s.is_active);
        if (!session) return [[], []];
        const user = this.memDb.users.find((u) => u.id === session.user_id);
        const role = user ? this.memDb.roles.find((r) => r.id === user.role_id) : null;
        const dept = user?.department_id ? this.memDb.departments.find((d) => d.id === user.department_id) : null;
        return [
          [
            {
              session_id: session.id,
              user_id: session.user_id,
              last_activity_at: session.last_activity_at,
              expires_at: session.expires_at,
              is_active: session.is_active,
              newer_active_sessions: 0,
              user_username: user?.username,
              user_email: user?.email,
              user_full_name: user?.full_name,
              must_change_password: user?.must_change_password,
              is_locked: user?.is_locked,
              is_suspended: user?.is_suspended,
              is_deactivated: user?.is_deactivated,
              department_id: user?.department_id || null,
              department_name: dept?.name || null,
              role_code: role?.code,
              role_name: role?.name,
            },
          ],
          [],
        ];
      }
    }

    if (upper.startsWith('UPDATE SESSIONS') || upper.startsWith('UPDATE `SESSIONS`')) {
      if (upper.includes('IS_ACTIVE = FALSE WHERE USER_ID = ?')) {
        const userId = params[0];
        let affected = 0;
        this.memDb.sessions.forEach((s) => {
          if (s.user_id === userId && s.is_active) {
            s.is_active = false;
            affected++;
          }
        });
        return [{ affectedRows: affected }, []];
      }
      if (upper.includes('LAST_ACTIVITY_AT = NOW()')) {
        const tokenHash = params[0];
        const session = this.memDb.sessions.find((s) => s.token_hash === tokenHash);
        if (session) {
          session.last_activity_at = new Date().toISOString();
          return [{ affectedRows: 1 }, []];
        }
      }
      return [{ affectedRows: 0 }, []];
    }

    if (upper.startsWith('INSERT INTO SESSIONS') || upper.startsWith('INSERT INTO `SESSIONS`')) {
      const id = this.memDb.generateId('sessions');
      this.memDb.sessions.push({
        id,
        user_id: params[0],
        token_hash: params[1],
        ip_address: params[2],
        user_agent: params[3],
        last_activity_at: new Date().toISOString(),
        expires_at: new Date(Date.now() + 3600000).toISOString(),
        is_active: true,
        created_at: new Date().toISOString(),
      });
      return [{ insertId: id, affectedRows: 1 }, []];
    }

    // 5. Audit Logs queries
    if (upper.startsWith('INSERT INTO AUDIT_LOGS') || upper.startsWith('INSERT INTO `AUDIT_LOGS`')) {
      const id = this.memDb.generateId('auditLogs');
      this.memDb.auditLogs.push({
        id,
        actor_id: params[0],
        action: params[1],
        target_type: params[2],
        target_id: params[3],
        ip_address: params[4],
        details: params[5] ? JSON.parse(typeof params[5] === 'string' ? params[5] : JSON.stringify(params[5])) : null,
        created_at: new Date().toISOString(),
      });
      return [{ insertId: id, affectedRows: 1 }, []];
    }

    // 6. Fee Structures queries
    if (upper.includes('FROM FEE_STRUCTURES') || upper.includes('FROM `FEE_STRUCTURES`')) {
      if (upper.includes('WHERE ACADEMIC_YEAR = ? AND ADMISSION_CATEGORY = ?') || upper.includes('WHERE `ACADEMIC_YEAR` = ? AND `ADMISSION_CATEGORY` = ?')) {
        const year = params[0];
        const cat = params[1];
        const studyYear = params[2] !== undefined ? parseInt(params[2], 10) : 1;
        const found = this.memDb.feeStructures.filter(
          (fs) => fs.academic_year === year && fs.admission_category === cat && (Number(fs.year_of_study) === studyYear || upper.includes('LIMIT 1'))
        );
        return [found, []];
      }
      const academicYear = params.find((p) => typeof p === 'string' && p.includes('-')) || '2026-2027';
      const rows = this.memDb.feeStructures.filter((fs) => fs.academic_year === academicYear);
      return [rows, []];
    }

    if (upper.startsWith('INSERT INTO FEE_STRUCTURES') || upper.startsWith('INSERT INTO `FEE_STRUCTURES`')) {
      const id = this.memDb.generateId('feeStructures');
      this.memDb.feeStructures.push({
        id,
        academic_year: params[0],
        admission_category: params[1],
        year_of_study: params[2] || 1,
        college_fee: parseFloat(params[3]),
        development_fee: parseFloat(params[4]),
        mess_fee: parseFloat(params[5] || 30000),
        hostel_fee: parseFloat(params[6] || 30000),
        total_annual_fee: parseFloat(params[7]),
        description: params[8] || '',
        is_active: params[9] !== undefined ? Boolean(params[9]) : true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
      return [{ insertId: id, affectedRows: 1 }, []];
    }

    if (upper.startsWith('UPDATE FEE_STRUCTURES') || upper.startsWith('UPDATE `FEE_STRUCTURES`')) {
      const structureId = params[params.length - 1];
      const structure = this.memDb.feeStructures.find((fs) => fs.id === structureId);
      if (structure) {
        if (upper.includes('ACADEMIC_YEAR = ?')) {
          structure.academic_year = params[0];
          structure.admission_category = params[1];
          structure.year_of_study = params[2];
          structure.college_fee = parseFloat(params[3]);
          structure.development_fee = parseFloat(params[4]);
          structure.mess_fee = parseFloat(params[5]);
          structure.hostel_fee = parseFloat(params[6]);
          structure.total_annual_fee = parseFloat(params[7]);
          structure.description = params[8];
          structure.is_active = Boolean(params[9]);
        } else {
          structure.college_fee = parseFloat(params[0]);
          structure.development_fee = parseFloat(params[1]);
          structure.mess_fee = parseFloat(params[2]);
          structure.hostel_fee = parseFloat(params[3]);
          structure.total_annual_fee = parseFloat(params[4]);
          structure.description = params[5];
          structure.is_active = Boolean(params[6]);
        }
        structure.updated_at = new Date().toISOString();
        return [{ affectedRows: 1 }, []];
      }
      return [{ affectedRows: 0 }, []];
    }

    // 7. Students queries
    if (upper.includes('FROM STUDENTS') || upper.includes('FROM `STUDENTS`')) {
      if (upper.includes('WHERE STUDENT_ID_NUMBER = ?')) {
        const studentIdNumber = String(params[0]).toUpperCase();
        const found = this.memDb.students.filter((s) => s.student_id_number.toUpperCase() === studentIdNumber);
        return [found, []];
      }

      if (upper.includes('WHERE S.ID = ?') || upper.includes('WHERE ID = ?')) {
        const studentId = parseInt(params[0], 10);
        const student = this.memDb.students.find((s) => s.id === studentId);
        return [student ? [student] : [], []];
      }

      if (upper.includes('COUNT(*) AS STUDENT_COUNT')) {
        return [[{ student_count: this.memDb.students.length }], []];
      }

      // List students with joined assessment & payments
      const results = this.memDb.students.map((s) => {
        const assessment = this.memDb.assessments.find((a) => a.student_id === s.id);
        const payments = this.memDb.payments.filter((p) => p.student_id === s.id && p.status === 'VERIFIED');
        const pendingPayments = this.memDb.payments.filter((p) => p.student_id === s.id && p.status === 'PENDING_VERIFICATION');

        const totalPaid = payments.reduce((sum, p) => sum + p.amount, 0);
        const totalPending = pendingPayments.reduce((sum, p) => sum + p.amount, 0);

        return {
          id: s.id,
          student_id_number: s.student_id_number,
          full_name: s.full_name,
          admission_category: s.admission_category,
          admission_year: s.admission_year,
          current_year_of_study: s.current_year_of_study,
          is_kea_eligible: s.is_kea_eligible,
          kea_acknowledgement_no: s.kea_acknowledgement_no,
          mess_enrolled: s.mess_enrolled,
          hostel_enrolled: s.hostel_enrolled,
          contact_phone: s.contact_phone,
          contact_email: s.contact_email,
          status: s.status,
          created_at: s.created_at,
          current_assessment_id: assessment?.id || null,
          academic_year: assessment?.academic_year || '2026-2027',
          is_kea_exception_applied: assessment?.is_kea_exception_applied || false,
          kea_exception_reason: assessment?.kea_exception_reason || null,
          assessed_college_fee: assessment?.assessed_college_fee || 0,
          assessed_development_fee: assessment?.assessed_development_fee || 0,
          assessed_mess_fee: assessment?.assessed_mess_fee || 0,
          assessed_hostel_fee: assessment?.assessed_hostel_fee || 0,
          total_assessed_fee: assessment?.total_assessed_fee || 0,
          concession_total: assessment?.concession_total || 0,
          revised_payable: assessment?.revised_payable || 0,
          total_paid: totalPaid,
          total_pending: totalPending,
        };
      });

      return [results, []];
    }

    if (upper.startsWith('INSERT INTO STUDENTS') || upper.startsWith('INSERT INTO `STUDENTS`')) {
      const id = this.memDb.generateId('students');
      this.memDb.students.push({
        id,
        student_id_number: params[0],
        full_name: params[1],
        admission_category: params[2],
        admission_year: params[3],
        current_year_of_study: params[4],
        is_kea_eligible: Boolean(params[5]),
        kea_acknowledgement_no: params[6] || null,
        mess_enrolled: Boolean(params[7]),
        hostel_enrolled: Boolean(params[8]),
        contact_phone: params[9] || null,
        contact_email: params[10] || null,
        status: 'ACTIVE',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
      return [{ insertId: id, affectedRows: 1 }, []];
    }

    // 8. Assessments queries
    if (upper.includes('FROM STUDENT_FEE_ASSESSMENTS') || upper.includes('FROM `STUDENT_FEE_ASSESSMENTS`')) {
      if (upper.includes('SUM(TOTAL_ASSESSED_FEE)') || upper.includes('SUM(REVISED_PAYABLE)')) {
        const total = this.memDb.assessments.reduce((sum, a) => sum + (a.revised_payable || a.total_assessed_fee), 0);
        return [[{ total_assessed: total }], []];
      }

      if (upper.includes('WHERE STUDENT_ID = ?') || upper.includes('WHERE SFA.STUDENT_ID = ?')) {
        const studentId = parseInt(params[0], 10);
        const list = this.memDb.assessments
          .filter((a) => a.student_id === studentId)
          .map((a) => {
            const user = this.memDb.users.find((u) => u.id === a.assessed_by);
            return {
              ...a,
              assessor_name: user?.full_name || 'System Assessor',
            };
          });
        return [list, []];
      }

      if (upper.includes('WHERE ID = ?') || upper.includes('WHERE SFA.ID = ?')) {
        const assessmentId = parseInt(params[0], 10);
        const a = this.memDb.assessments.find((item) => item.id === assessmentId);
        return [a ? [a] : [], []];
      }
    }

    if (upper.startsWith('INSERT INTO STUDENT_FEE_ASSESSMENTS') || upper.startsWith('INSERT INTO `STUDENT_FEE_ASSESSMENTS`')) {
      const id = this.memDb.generateId('assessments');
      this.memDb.assessments.push({
        id,
        student_id: params[0],
        academic_year: params[1],
        year_of_study: params[2],
        admission_category: params[3],
        is_kea_exception_applied: Boolean(params[4]),
        kea_exception_reason: params[5] || null,
        assessed_college_fee: parseFloat(params[6]),
        assessed_development_fee: parseFloat(params[7]),
        assessed_mess_fee: parseFloat(params[8] || 0),
        assessed_hostel_fee: parseFloat(params[9] || 0),
        total_assessed_fee: parseFloat(params[10]),
        concession_total: parseFloat(params[11] || 0),
        revised_payable: parseFloat(params[12] || params[10]),
        notes: params[13] || null,
        assessed_by: params[14],
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
      return [{ insertId: id, affectedRows: 1 }, []];
    }

    if (upper.startsWith('UPDATE STUDENT_FEE_ASSESSMENTS') || upper.startsWith('UPDATE `STUDENT_FEE_ASSESSMENTS`')) {
      const assessmentId = params[params.length - 1];
      const a = this.memDb.assessments.find((item) => item.id === assessmentId);
      if (a) {
        if (upper.includes('ASSESSED_COLLEGE_FEE = ?')) {
          a.assessed_college_fee = parseFloat(params[0]);
          a.assessed_development_fee = parseFloat(params[1]);
          a.total_assessed_fee = parseFloat(params[2]);
          a.revised_payable = parseFloat(params[3]);
          if (params[4]) a.notes = params[4];
        } else if (upper.includes('CONCESSION_TOTAL = ?')) {
          a.concession_total = parseFloat(params[0]);
          a.revised_payable = parseFloat(params[1]);
        } else if (upper.includes('ASSESSED_MESS_FEE = ?')) {
          a.assessed_mess_fee = parseFloat(params[0]);
          a.assessed_hostel_fee = parseFloat(params[1]);
          a.total_assessed_fee = parseFloat(params[2]);
          a.revised_payable = parseFloat(params[3]);
        }
        a.updated_at = new Date().toISOString();
        return [{ affectedRows: 1 }, []];
      }
      return [{ affectedRows: 0 }, []];
    }

    // 9. Service Enrollments queries
    if (upper.includes('FROM SERVICE_ENROLLMENTS') || upper.includes('FROM `SERVICE_ENROLLMENTS`')) {
      const studentId = parseInt(params[0], 10);
      const list = this.memDb.serviceEnrollments
        .filter((se) => se.student_id === studentId)
        .map((se) => {
          const user = this.memDb.users.find((u) => u.id === se.created_by);
          return {
            ...se,
            creator_name: user?.full_name || 'Staff',
          };
        });
      return [list, []];
    }

    if (upper.startsWith('INSERT INTO SERVICE_ENROLLMENTS') || upper.startsWith('INSERT INTO `SERVICE_ENROLLMENTS`')) {
      const id = this.memDb.generateId('serviceEnrollments');
      this.memDb.serviceEnrollments.push({
        id,
        student_id: params[0],
        service_type: params[1],
        start_date: params[2],
        end_date: params[3] || null,
        annual_fee: parseFloat(params[4]),
        status: params[5] || 'ACTIVE',
        created_by: params[6],
        notes: params[7] || null,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
      return [{ insertId: id, affectedRows: 1 }, []];
    }

    if (upper.startsWith('UPDATE SERVICE_ENROLLMENTS') || upper.startsWith('UPDATE `SERVICE_ENROLLMENTS`')) {
      const enrollmentId = params[params.length - 1];
      const se = this.memDb.serviceEnrollments.find((item) => item.id === enrollmentId);
      if (se) {
        se.end_date = params[0];
        se.status = params[1];
        se.notes = params[2] || se.notes;
        se.updated_at = new Date().toISOString();
        return [{ affectedRows: 1 }, []];
      }
      return [{ affectedRows: 0 }, []];
    }

    // 10. Fee Concessions queries
    if (upper.includes('FROM FEE_CONCESSIONS') || upper.includes('FROM `FEE_CONCESSIONS`')) {
      const studentId = parseInt(params[0], 10);
      const list = this.memDb.concessions
        .filter((c) => c.student_id === studentId)
        .map((c) => {
          const user = this.memDb.users.find((u) => u.id === c.authorized_by);
          return {
            ...c,
            authorizer_name: user?.full_name || 'Authorized Officer',
          };
        });
      return [list, []];
    }

    if (upper.startsWith('INSERT INTO FEE_CONCESSIONS') || upper.startsWith('INSERT INTO `FEE_CONCESSIONS`')) {
      const id = this.memDb.generateId('concessions');
      this.memDb.concessions.push({
        id,
        student_id: params[0],
        assessment_id: params[1],
        fee_component: params[2],
        concession_type: params[3],
        value: parseFloat(params[4]),
        calculated_reduction: parseFloat(params[5]),
        reason: params[6],
        authorized_by: params[7],
        created_at: new Date().toISOString(),
      });
      return [{ insertId: id, affectedRows: 1 }, []];
    }

    // 11. Payments queries
    if (upper.includes('FROM FEE_PAYMENTS') || upper.includes('FROM `FEE_PAYMENTS`')) {
      if (upper.includes('SUM(AMOUNT)')) {
        const verifiedOnly = upper.includes("STATUS = 'VERIFIED'") || upper.includes("STATUS = 'RECORDED'");
        let list = this.memDb.payments.filter((p) => (verifiedOnly ? p.status === 'VERIFIED' : true));
        if (upper.includes('WHERE STUDENT_ID = ?') || upper.includes('WHERE FP.STUDENT_ID = ?')) {
          const studentId = parseInt(params[0], 10);
          list = list.filter((p) => p.student_id === studentId);
        }
        const total = list.reduce((sum, p) => sum + p.amount, 0);
        return [[{ total_collected: total, total_paid: total }], []];
      }

      if (upper.includes('WHERE STUDENT_ID = ?') || upper.includes('WHERE FP.STUDENT_ID = ?')) {
        const studentId = parseInt(params[0], 10);
        const list = this.memDb.payments
          .filter((p) => p.student_id === studentId)
          .map((p) => {
            const recorder = this.memDb.users.find((u) => u.id === p.recorded_by);
            const verifier = p.verified_by ? this.memDb.users.find((u) => u.id === p.verified_by) : null;
            const reverser = p.reversed_by ? this.memDb.users.find((u) => u.id === p.reversed_by) : null;
            const receipt = this.memDb.receipts.find((r) => r.payment_id === p.id);
            return {
              ...p,
              recorder_name: recorder?.full_name || 'Accounts Staff',
              verifier_name: verifier?.full_name || null,
              reverser_name: reverser?.full_name || null,
              receipt_id: receipt?.id || null,
              receipt_number: receipt?.receipt_number || null,
              receipt_type: receipt?.receipt_type || null,
              receipt_status: receipt?.status || null,
            };
          });
        return [list, []];
      }

      if (upper.includes('WHERE ID = ?') || upper.includes('WHERE FP.ID = ?')) {
        const paymentId = parseInt(params[0], 10);
        const p = this.memDb.payments.find((item) => item.id === paymentId);
        return [p ? [p] : [], []];
      }

      if (upper.includes('STUDENT_TX_REF = ?')) {
        const txRef = String(params[0]).trim();
        const existing = this.memDb.payments.filter(
          (p) => p.student_tx_ref && p.student_tx_ref.toLowerCase() === txRef.toLowerCase() && p.status !== 'REVERSED'
        );
        return [existing, []];
      }

      // Default payments list
      return [this.memDb.payments, []];
    }

    if (upper.startsWith('INSERT INTO FEE_PAYMENTS') || upper.startsWith('INSERT INTO `FEE_PAYMENTS`')) {
      const id = this.memDb.generateId('payments');
      this.memDb.payments.push({
        id,
        assessment_id: params[0],
        student_id: params[1],
        payment_reference: params[2],
        amount: parseFloat(params[3]),
        destination: params[4] || 'COLLEGE_ACCOUNT',
        payment_method: params[5] || 'CASH',
        bank_transaction_ref: params[6] || null,
        student_tx_ref: params[7] || null,
        passbook_tx_ref: params[8] || null,
        bank_name: params[9] || null,
        payment_date: params[10],
        recorded_by: params[11],
        notes: params[12] || null,
        status: params[13] || 'VERIFIED',
        verified_by: params[14] || null,
        verified_at: params[15] || null,
        rejection_reason: null,
        reversal_reason: null,
        reversed_by: null,
        reversed_at: null,
        created_at: new Date().toISOString(),
      });
      return [{ insertId: id, affectedRows: 1 }, []];
    }

    if (upper.startsWith('UPDATE FEE_PAYMENTS') || upper.startsWith('UPDATE `FEE_PAYMENTS`')) {
      const paymentId = params[params.length - 1];
      const p = this.memDb.payments.find((item) => item.id === paymentId);
      if (p) {
        if (upper.includes("STATUS = 'VERIFIED'") || upper.includes('PASSBOOK_TX_REF = ?')) {
          p.status = 'VERIFIED';
          p.passbook_tx_ref = params[0];
          p.verified_by = params[1];
          p.verified_at = new Date().toISOString();
        } else if (upper.includes("STATUS = 'REJECTED'") || upper.includes('REJECTION_REASON = ?')) {
          p.status = 'REJECTED';
          p.rejection_reason = params[0];
          p.verified_by = params[1];
          p.verified_at = new Date().toISOString();
        } else if (upper.includes("STATUS = 'REVERSED'") || upper.includes('REVERSAL_REASON = ?')) {
          p.status = 'REVERSED';
          p.reversal_reason = params[0];
          p.reversed_by = params[1];
          p.reversed_at = new Date().toISOString();
        }
        return [{ affectedRows: 1 }, []];
      }
      return [{ affectedRows: 0 }, []];
    }

    // 12. Receipts queries
    if (upper.includes('FROM FEE_RECEIPTS') || upper.includes('FROM `FEE_RECEIPTS`')) {
      if (upper.includes('WHERE PAYMENT_ID = ?') || upper.includes('WHERE FR.PAYMENT_ID = ?')) {
        const paymentId = parseInt(params[0], 10);
        const r = this.memDb.receipts.find((item) => item.payment_id === paymentId);
        return [r ? [r] : [], []];
      }

      if (upper.includes('WHERE ID = ?') || upper.includes('WHERE FR.ID = ?')) {
        const receiptId = parseInt(params[0], 10);
        const r = this.memDb.receipts.find((item) => item.id === receiptId);
        return [r ? [r] : [], []];
      }

      if (upper.includes('COUNT(*) AS PENDING_COUNT')) {
        const count = this.memDb.receipts.filter((r) => r.status === 'PENDING_APPROVAL').length;
        return [[{ pending_count: count }], []];
      }

      return [this.memDb.receipts, []];
    }

    if (upper.startsWith('INSERT INTO FEE_RECEIPTS') || upper.startsWith('INSERT INTO `FEE_RECEIPTS`')) {
      const id = this.memDb.generateId('receipts');
      this.memDb.receipts.push({
        id,
        payment_id: params[0],
        student_id: params[1],
        receipt_number: params[2],
        receipt_type: params[3] || 'FINAL_COLLEGE_RECEIPT',
        destination: params[4] || 'COLLEGE_ACCOUNT',
        amount: parseFloat(params[5] || 0),
        requested_by: params[6],
        status: params[7] || 'APPROVED',
        reviewed_by: params[8] || null,
        reviewed_at: params[9] || null,
        rejection_reason: null,
        issued_at: new Date().toISOString(),
        created_at: new Date().toISOString(),
      });
      return [{ insertId: id, affectedRows: 1 }, []];
    }

    if (upper.startsWith('UPDATE FEE_RECEIPTS') || upper.startsWith('UPDATE `FEE_RECEIPTS`')) {
      const receiptId = params[params.length - 1];
      const r = this.memDb.receipts.find((item) => item.id === receiptId);
      if (r) {
        if (upper.includes('RECEIPT_NUMBER = ?, RECEIPT_TYPE = ?, STATUS = ?')) {
          r.receipt_number = params[0];
          r.receipt_type = params[1];
          r.status = params[2];
          r.reviewed_by = params[3];
          r.reviewed_at = new Date().toISOString();
        } else if (upper.includes('STATUS = ?, REJECTION_REASON = ?')) {
          r.status = params[0];
          r.rejection_reason = params[1];
          r.reviewed_by = params[2];
          r.reviewed_at = new Date().toISOString();
        }
        return [{ affectedRows: 1 }, []];
      }
      return [{ affectedRows: 0 }, []];
    }

    // Generic fallback for any other statements
    return [[], []];
  }
}
