import bcrypt from 'bcryptjs';

export interface MemoryRole {
  id: number;
  code: string;
  name: string;
  description: string;
}

export interface MemoryDepartment {
  id: number;
  code: string;
  name: string;
  description: string;
  created_at: string;
  updated_at: string;
}

export interface MemoryUser {
  id: number;
  username: string;
  email: string;
  password_hash: string;
  role_id: number;
  department_id: number | null;
  full_name: string;
  must_change_password: boolean;
  failed_attempts: number;
  is_locked: boolean;
  locked_at: string | null;
  is_suspended: boolean;
  suspended_at: string | null;
  is_deactivated: boolean;
  deactivated_at: string | null;
  created_by: number | null;
  created_at: string;
  updated_at: string;
}

export interface MemorySession {
  id: number;
  user_id: number;
  token_hash: string;
  ip_address: string | null;
  user_agent: string | null;
  last_activity_at: string;
  expires_at: string | null;
  is_active: boolean;
  created_at: string;
}

export interface MemoryFeeStructure {
  id: number;
  academic_year: string;
  admission_category: 'GOVERNMENT' | 'MANAGEMENT_PRIVATE' | 'NRI';
  year_of_study: number;
  college_fee: number;
  development_fee: number;
  mess_fee: number;
  hostel_fee: number;
  total_annual_fee: number;
  description: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface MemoryStudent {
  id: number;
  student_id_number: string;
  full_name: string;
  admission_category: 'GOVERNMENT' | 'MANAGEMENT_PRIVATE' | 'NRI';
  admission_year: number;
  current_year_of_study: number;
  is_kea_eligible: boolean;
  kea_acknowledgement_no: string | null;
  mess_enrolled: boolean;
  hostel_enrolled: boolean;
  contact_phone: string | null;
  contact_email: string | null;
  status: 'ACTIVE' | 'PASSED_OUT' | 'SUSPENDED';
  created_at: string;
  updated_at: string;
}

export interface MemoryServiceEnrollment {
  id: number;
  student_id: number;
  service_type: 'MESS' | 'HOSTEL';
  start_date: string;
  end_date: string | null;
  annual_fee: number;
  status: 'ACTIVE' | 'COMPLETED' | 'CANCELLED';
  created_by: number;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface MemoryFeeAssessment {
  id: number;
  student_id: number;
  academic_year: string;
  year_of_study: number;
  admission_category: 'GOVERNMENT' | 'MANAGEMENT_PRIVATE' | 'NRI';
  is_kea_exception_applied: boolean;
  kea_exception_reason: string | null;
  assessed_college_fee: number;
  assessed_development_fee: number;
  assessed_mess_fee: number;
  assessed_hostel_fee: number;
  total_assessed_fee: number;
  concession_total: number;
  revised_payable: number;
  notes: string | null;
  assessed_by: number;
  created_at: string;
  updated_at: string;
}

export interface MemoryFeeConcession {
  id: number;
  student_id: number;
  assessment_id: number;
  fee_component: string;
  concession_type: 'FIXED' | 'PERCENTAGE';
  value: number;
  calculated_reduction: number;
  reason: string;
  authorized_by: number;
  created_at: string;
}

export interface MemoryFeePayment {
  id: number;
  assessment_id: number;
  student_id: number;
  payment_reference: string;
  amount: number;
  destination: 'COLLEGE_ACCOUNT' | 'SECRETARY_DEV_ACCOUNT';
  payment_method: 'CASH' | 'BANK_TRANSFER' | 'ONLINE_DEV';
  bank_transaction_ref: string | null;
  student_tx_ref: string | null;
  passbook_tx_ref: string | null;
  bank_name: string | null;
  payment_date: string;
  recorded_by: number;
  notes: string | null;
  status: 'PENDING_VERIFICATION' | 'VERIFIED' | 'REJECTED' | 'REVERSED';
  verified_by: number | null;
  verified_at: string | null;
  rejection_reason: string | null;
  reversal_reason: string | null;
  reversed_by: number | null;
  reversed_at: string | null;
  created_at: string;
}

export interface MemoryFeeReceipt {
  id: number;
  payment_id: number;
  student_id: number;
  receipt_number: string;
  receipt_type: 'PROVISIONAL_ACKNOWLEDGEMENT' | 'FINAL_COLLEGE_RECEIPT' | 'SECRETARY_DEV_RECEIPT';
  destination: 'COLLEGE_ACCOUNT' | 'SECRETARY_DEV_ACCOUNT';
  amount: number;
  requested_by: number;
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED';
  reviewed_by: number | null;
  reviewed_at: string | null;
  rejection_reason: string | null;
  issued_at: string;
  created_at: string;
}

export interface MemoryAuditLog {
  id: number;
  actor_id: number | null;
  action: string;
  target_type: string | null;
  target_id: string | null;
  ip_address: string | null;
  details: any;
  created_at: string;
}

export class MemoryDatabase {
  private static instance: MemoryDatabase;

  roles: MemoryRole[] = [];
  departments: MemoryDepartment[] = [];
  users: MemoryUser[] = [];
  sessions: MemorySession[] = [];
  auditLogs: MemoryAuditLog[] = [];
  feeStructures: MemoryFeeStructure[] = [];
  students: MemoryStudent[] = []; // Empty student list as required
  serviceEnrollments: MemoryServiceEnrollment[] = [];
  assessments: MemoryFeeAssessment[] = [];
  concessions: MemoryFeeConcession[] = [];
  payments: MemoryFeePayment[] = [];
  receipts: MemoryFeeReceipt[] = [];

  private nextIds: Record<string, number> = {
    roles: 1,
    departments: 1,
    users: 1,
    sessions: 1,
    auditLogs: 1,
    feeStructures: 1,
    students: 1,
    serviceEnrollments: 1,
    assessments: 1,
    concessions: 1,
    payments: 1,
    receipts: 1,
  };

  private initialized = false;

  public static getInstance(): MemoryDatabase {
    if (!MemoryDatabase.instance) {
      MemoryDatabase.instance = new MemoryDatabase();
      MemoryDatabase.instance.init();
    }
    return MemoryDatabase.instance;
  }

  private init(): void {
    if (this.initialized) return;
    this.initialized = true;

    // 1. Seed Roles
    const initialRoles: Array<Omit<MemoryRole, 'id'>> = [
      { code: 'SUPER_ADMIN', name: 'Super Administrator', description: 'Institutional super administrative control and security management' },
      { code: 'PRINCIPAL', name: 'Principal', description: 'Executive institutional governance, faculty supervision, and audit review' },
      { code: 'SECRETARY', name: 'Secretary', description: 'Trust and institutional administrative utilities and records' },
      { code: 'HOD', name: 'Head of Department', description: 'Academic and clinical department leadership and postings' },
      { code: 'FACULTY', name: 'Faculty Member', description: 'Teaching, clinical instruction, and marks entry' },
      { code: 'STAFF', name: 'Administrative Staff', description: 'Office administration and departmental operations' },
      { code: 'OFFICE', name: 'Office & Accounts Staff', description: 'Student fee management, payment collection, and receipt request submission' },
      { code: 'STUDENT', name: 'Student', description: 'Student academic portal and examination record view' },
      { code: 'LIBRARY', name: 'Library Staff', description: 'Library administration and circulation management' },
      { code: 'DEPARTMENT', name: 'Department Account', description: 'Shared institutional department account for marks and department records' },
    ];

    for (const r of initialRoles) {
      this.roles.push({ id: this.nextIds.roles++, ...r });
    }

    // 2. Seed Ayurvedic Departments
    const initialDepts: Array<Omit<MemoryDepartment, 'id' | 'created_at' | 'updated_at'>> = [
      { code: 'SAMHITA_SIDDHANTA', name: 'Ayurveda Samhita & Siddhanta', description: 'Department of Basic Principles & Ayurvedic Philosophy' },
      { code: 'RACHANA_SHARIR', name: 'Rachana Sharir', description: 'Department of Human Anatomy & Ayurvedic Embryology' },
      { code: 'KRIYA_SHARIR', name: 'Kriya Sharir', description: 'Department of Human Physiology & Dosh-Dhatu-Mala Vigyana' },
      { code: 'DRAVYAGUNA', name: 'Dravyaguna Vijnana', description: 'Department of Ayurvedic Pharmacology & Materia Medica' },
      { code: 'RASA_SHASTRA', name: 'Rasa Shastra & Bhaishajya Kalpana', description: 'Department of Iatrochemistry & Pharmaceutical Science' },
      { code: 'ROGA_NIDANA', name: 'Roga Nidana & Vikriti Vigyana', description: 'Department of Diagnostic Pathology & Clinical Investigation' },
      { code: 'SWASTHAVRITTA', name: 'Swasthavritta & Yoga', description: 'Department of Preventive Medicine, Hygiene & Yoga' },
      { code: 'AGADA_TANTRA', name: 'Agada Tantra & Vidhi Vaidyaka', description: 'Department of Toxicology & Forensic Jurisprudence' },
      { code: 'KAYACHIKITSA', name: 'Kayachikitsa', description: 'Department of General Internal Medicine' },
      { code: 'PANCHAKARMA', name: 'Panchakarma', description: 'Department of Bio-Purification & Detoxification Therapies' },
      { code: 'SHALYA_TANTRA', name: 'Shalya Tantra', description: 'Department of General Surgery & Para-Surgical Techniques' },
      { code: 'SHALAKYA_TANTRA', name: 'Shalakya Tantra', description: 'Department of Ophthalmology & ENT (Urdhwanga Roga)' },
      { code: 'PRASUTI_STRI', name: 'Prasuti Tantra & Stri Roga', description: 'Department of Obstetrics & Gynecology' },
      { code: 'KAUMARABHRITYA', name: 'Kaumarbhritya (Balaroga)', description: 'Department of Pediatrics & Neonatal Care' },
    ];

    const deptNow = new Date().toISOString();
    for (const d of initialDepts) {
      this.departments.push({ id: this.nextIds.departments++, created_at: deptNow, updated_at: deptNow, ...d });
    }

    // 3. Seed Default Institutional Users for Development & Standalone Testing
    const defaultHash = bcrypt.hashSync('Admin@12345', 10);
    const initialUsers: Array<Omit<MemoryUser, 'id' | 'created_at' | 'updated_at'>> = [
      {
        username: 'superadmin',
        email: 'admin@kamch.ac.in',
        password_hash: defaultHash,
        role_id: 1, // SUPER_ADMIN
        department_id: null,
        full_name: 'KAMCH Super Administrator',
        must_change_password: false,
        failed_attempts: 0,
        is_locked: false,
        locked_at: null,
        is_suspended: false,
        suspended_at: null,
        is_deactivated: false,
        deactivated_at: null,
        created_by: null,
      },
      {
        username: 'principal',
        email: 'principal@kamch.ac.in',
        password_hash: bcrypt.hashSync('Principal@12345', 10),
        role_id: 2, // PRINCIPAL
        department_id: null,
        full_name: 'Dr. S. K. Sharma (Principal)',
        must_change_password: false,
        failed_attempts: 0,
        is_locked: false,
        locked_at: null,
        is_suspended: false,
        suspended_at: null,
        is_deactivated: false,
        deactivated_at: null,
        created_by: 1,
      },
      {
        username: 'secretary',
        email: 'secretary@kamch.ac.in',
        password_hash: bcrypt.hashSync('Secretary@12345', 10),
        role_id: 3, // SECRETARY
        department_id: null,
        full_name: 'Sri R. K. Verma (Secretary)',
        must_change_password: false,
        failed_attempts: 0,
        is_locked: false,
        locked_at: null,
        is_suspended: false,
        suspended_at: null,
        is_deactivated: false,
        deactivated_at: null,
        created_by: 1,
      },
      {
        username: 'accounts',
        email: 'accounts@kamch.ac.in',
        password_hash: bcrypt.hashSync('Office@12345', 10),
        role_id: 7, // OFFICE
        department_id: null,
        full_name: 'Accounts & Fees Officer',
        must_change_password: false,
        failed_attempts: 0,
        is_locked: false,
        locked_at: null,
        is_suspended: false,
        suspended_at: null,
        is_deactivated: false,
        deactivated_at: null,
        created_by: 1,
      },
      {
        username: 'hod_ayur',
        email: 'hod.ayur@kamch.ac.in',
        password_hash: bcrypt.hashSync('Dept@12345', 10),
        role_id: 10, // DEPARTMENT
        department_id: 9, // Kayachikitsa
        full_name: 'Dept of Kayachikitsa',
        must_change_password: false,
        failed_attempts: 0,
        is_locked: false,
        locked_at: null,
        is_suspended: false,
        suspended_at: null,
        is_deactivated: false,
        deactivated_at: null,
        created_by: 1,
      },
      {
        username: 'library',
        email: 'library@kamch.ac.in',
        password_hash: bcrypt.hashSync('Library@12345', 10),
        role_id: 9, // LIBRARY
        department_id: null,
        full_name: 'KAMCH Central Library Staff',
        must_change_password: false,
        failed_attempts: 0,
        is_locked: false,
        locked_at: null,
        is_suspended: false,
        suspended_at: null,
        is_deactivated: false,
        deactivated_at: null,
        created_by: 1,
      },
    ];

    const now = new Date().toISOString();
    for (const u of initialUsers) {
      this.users.push({ id: this.nextIds.users++, created_at: now, updated_at: now, ...u });
    }

    // 3. Seed Initial Approved Fee Structures per Section 4 Specifications
    // Government: College ₹75,750, Development ₹50,000, Mess ₹30,000, Hostel ₹30,000. Base: ₹1,25,750
    // Private: Combined College & Dev ₹4,00,000, Mess ₹30,000, Hostel ₹30,000. Base: ₹4,00,000
    // NRI: Combined College & Dev ₹6,00,000, Mess ₹30,000, Hostel ₹30,000. Base: ₹6,00,000
    this.feeStructures.push(
      {
        id: this.nextIds.feeStructures++,
        academic_year: '2026-2027',
        admission_category: 'GOVERNMENT',
        year_of_study: 1,
        college_fee: 75750.00,
        development_fee: 50000.00,
        mess_fee: 30000.00,
        hostel_fee: 30000.00,
        total_annual_fee: 125750.00,
        description: 'Government Seat Base: College ₹75,750 + Dev ₹50,000 (Optional: Mess ₹30,000, Hostel ₹30,000)',
        is_active: true,
        created_at: now,
        updated_at: now,
      },
      {
        id: this.nextIds.feeStructures++,
        academic_year: '2026-2027',
        admission_category: 'MANAGEMENT_PRIVATE',
        year_of_study: 1,
        college_fee: 400000.00,
        development_fee: 0.00,
        mess_fee: 30000.00,
        hostel_fee: 30000.00,
        total_annual_fee: 400000.00,
        description: 'Private Seat Base: Combined College & Dev ₹4,00,000 (Optional: Mess ₹30,000, Hostel ₹30,000)',
        is_active: true,
        created_at: now,
        updated_at: now,
      },
      {
        id: this.nextIds.feeStructures++,
        academic_year: '2026-2027',
        admission_category: 'NRI',
        year_of_study: 1,
        college_fee: 600000.00,
        development_fee: 0.00,
        mess_fee: 30000.00,
        hostel_fee: 30000.00,
        total_annual_fee: 600000.00,
        description: 'NRI Seat Base: Combined College & Dev ₹6,00,000 (Optional: Mess ₹30,000, Hostel ₹30,000)',
        is_active: true,
        created_at: now,
        updated_at: now,
      }
    );

    // Students list is strictly EMPTY on initialization!
    console.log('[KAMCH ERP Memory Database] Initialized in-memory store (empty students list, initial fee structures ready).');
  }

  generateId(table: string): number {
    if (!this.nextIds[table]) this.nextIds[table] = 1;
    return this.nextIds[table]++;
  }
}
