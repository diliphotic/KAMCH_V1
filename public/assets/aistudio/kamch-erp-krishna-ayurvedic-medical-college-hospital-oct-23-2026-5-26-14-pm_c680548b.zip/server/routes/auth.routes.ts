import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { getPool } from '../db.ts';
import { requireAuth } from '../middleware/auth.ts';
import { validateCsrf, generateCsrfToken, setCsrfCookie } from '../middleware/csrf.ts';
import { recordAuditLog } from '../services/audit.ts';

export const authRouter = Router();

const SESSION_DURATION_MS = 60 * 60 * 1000; // 1 hour

/**
 * GET /api/auth/csrf
 * Returns a fresh CSRF token and sets the kamch_csrf cookie.
 */
authRouter.get('/csrf', (req: Request, res: Response) => {
  let token = req.cookies?.kamch_csrf;
  if (!token || typeof token !== 'string' || token.length < 16) {
    token = generateCsrfToken();
  }
  const isSecure = Boolean(req.secure || req.headers['x-forwarded-proto'] === 'https');
  setCsrfCookie(res, token, isSecure);
  res.json({ csrfToken: token });
});

/**
 * POST /api/auth/login
 * Public authentication endpoint:
 * - Accepts username or email and password
 * - Validates credentials using bcrypt
 * - Enforces 6 failed attempts lockout
 * - Invalids previous active sessions (single active session enforcement)
 * - Sets secure HTTP-only session cookie
 * - Generates CSRF token
 */
authRouter.post('/login', async (req: Request, res: Response): Promise<void> => {
  const { usernameOrEmail, password } = req.body || {};

  if (
    !usernameOrEmail ||
    !password ||
    typeof usernameOrEmail !== 'string' ||
    typeof password !== 'string' ||
    usernameOrEmail.trim() === '' ||
    password === ''
  ) {
    res.status(400).json({
      error: 'Username or email and password are required',
      code: 'MISSING_CREDENTIALS',
    });
    return;
  }

  const identifier = usernameOrEmail.trim();
  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    // Query user with row lock to prevent race conditions during concurrent logins
    const [userRows] = await connection.query<any[]>(
      `SELECT 
        u.id, 
        u.username, 
        u.email, 
        u.password_hash, 
        u.role_id, 
        u.department_id,
        u.full_name,
        u.must_change_password, 
        u.failed_attempts, 
        u.is_locked, 
        u.locked_at,
        u.is_suspended, 
        u.is_deactivated,
        r.code AS role_code, 
        r.name AS role_name
       FROM users u
       JOIN roles r ON u.role_id = r.id
       WHERE u.username = ? OR u.email = ?
       LIMIT 1
       FOR UPDATE`,
      [identifier, identifier]
    );

    // Constant-time generic rejection if user not found
    if (!userRows || userRows.length === 0) {
      await connection.commit();
      await recordAuditLog({
        action: 'LOGIN_FAILED',
        targetType: 'USER',
        ipAddress: req.ip || null,
        details: { reason: 'account_not_found', identifierProvided: identifier.length },
      });

      res.status(401).json({
        error: 'Invalid username/email or password',
        code: 'INVALID_CREDENTIALS',
      });
      return;
    }

    const user = userRows[0];

    // Check if account is deactivated
    if (user.is_deactivated) {
      await connection.commit();
      await recordAuditLog({
        actorId: user.id,
        action: 'LOGIN_REJECTED_DEACTIVATED',
        targetType: 'USER',
        targetId: String(user.id),
        ipAddress: req.ip || null,
      });

      res.status(403).json({
        error: 'This account has been deactivated. Historical records have been preserved.',
        code: 'ACCOUNT_DEACTIVATED',
      });
      return;
    }

    // Check if account is suspended
    if (user.is_suspended) {
      await connection.commit();
      await recordAuditLog({
        actorId: user.id,
        action: 'LOGIN_REJECTED_SUSPENDED',
        targetType: 'USER',
        targetId: String(user.id),
        ipAddress: req.ip || null,
        details: { suspendedAt: user.suspended_at },
      });

      res.status(403).json({
        error: 'This account has been suspended. Please contact the institutional administration.',
        code: 'ACCOUNT_SUSPENDED',
      });
      return;
    }

    // 30-Minute Temporary Lockout Check
    const LOCKOUT_DURATION_MS = 30 * 60 * 1000; // 30 minutes
    const nowMs = Date.now();

    if (user.is_locked && user.locked_at) {
      const lockedAtMs = new Date(user.locked_at).getTime();
      const elapsedMs = nowMs - lockedAtMs;

      if (elapsedMs < LOCKOUT_DURATION_MS) {
        // Lockout is still active
        const remainingMinutes = Math.max(1, Math.ceil((LOCKOUT_DURATION_MS - elapsedMs) / 60000));
        await connection.commit();
        await recordAuditLog({
          actorId: user.id,
          action: 'LOGIN_REJECTED_LOCKED',
          targetType: 'USER',
          targetId: String(user.id),
          ipAddress: req.ip || null,
          details: { remainingMinutes, lockedAt: user.locked_at },
        });

        res.status(403).json({
          error: `This account is temporarily locked due to 6 consecutive failed attempts. Please try again after ${remainingMinutes} minute${remainingMinutes > 1 ? 's' : ''}.`,
          code: 'ACCOUNT_LOCKED',
        });
        return;
      } else {
        // 30-minute lockout period has expired: allow login attempts again and reset lockout flag
        await connection.query(
          'UPDATE users SET is_locked = FALSE, locked_at = NULL, failed_attempts = 0 WHERE id = ?',
          [user.id]
        );
        user.is_locked = false;
        user.locked_at = null;
        user.failed_attempts = 0;
      }
    }

    // Verify password with bcrypt
    const isPasswordValid = await bcrypt.compare(password, user.password_hash);

    if (!isPasswordValid) {
      const newAttempts = user.failed_attempts + 1;

      if (newAttempts >= 6) {
        // Six consecutive failed attempts trigger 30-minute lockout
        await connection.query(
          'UPDATE users SET failed_attempts = ?, is_locked = TRUE, locked_at = NOW() WHERE id = ?',
          [newAttempts, user.id]
        );
        await connection.commit();

        await recordAuditLog({
          actorId: user.id,
          action: 'ACCOUNT_LOCKED',
          targetType: 'USER',
          targetId: String(user.id),
          ipAddress: req.ip || null,
          details: { consecutiveFailures: newAttempts, lockoutMinutes: 30 },
        });

        res.status(403).json({
          error: 'This account has been temporarily locked for 30 minutes due to 6 consecutive failed login attempts.',
          code: 'ACCOUNT_LOCKED',
        });
        return;
      } else {
        await connection.query(
          'UPDATE users SET failed_attempts = ? WHERE id = ?',
          [newAttempts, user.id]
        );
        await connection.commit();

        await recordAuditLog({
          actorId: user.id,
          action: 'LOGIN_FAILED',
          targetType: 'USER',
          targetId: String(user.id),
          ipAddress: req.ip || null,
          details: { failureCount: newAttempts },
        });

        res.status(401).json({
          error: 'Invalid username/email or password',
          code: 'INVALID_CREDENTIALS',
        });
        return;
      }
    }

    // Password is valid: reset failed attempts and lockout counter
    await connection.query(
      'UPDATE users SET failed_attempts = 0, is_locked = FALSE, locked_at = NULL WHERE id = ?',
      [user.id]
    );

    // Single active session enforcement:
    // Invalidate any existing active sessions for this user within the locked transaction
    const [prevSessionResult] = await connection.query<any>(
      'UPDATE sessions SET is_active = FALSE WHERE user_id = ? AND is_active = TRUE',
      [user.id]
    );
    const invalidatedCount = prevSessionResult?.affectedRows || 0;

    // Generate cryptographically secure random session token
    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');

    // Explicitly set expires_at (1 hour from now)
    await connection.query(
      `INSERT INTO sessions 
        (user_id, token_hash, ip_address, user_agent, last_activity_at, expires_at, is_active)
       VALUES (?, ?, ?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 1 HOUR), TRUE)`,
      [
        user.id,
        tokenHash,
        req.ip || null,
        req.headers['user-agent']?.slice(0, 255) || null,
      ]
    );

    // CRITICAL: Commit transaction immediately to release exclusive row lock on users table
    // and finalize session invalidation before any external audit logging
    await connection.commit();

    console.log(
      `[KAMCH Auth] Login successful for user "${user.username}" (id: ${user.id}). Previous active sessions invalidated: ${invalidatedCount}. IP: ${req.ip || 'unknown'}`
    );

    // Audit logs recorded strictly AFTER transaction commit to prevent InnoDB foreign key lock waits
    if (invalidatedCount > 0) {
      await recordAuditLog({
        actorId: user.id,
        action: 'PREVIOUS_SESSION_INVALIDATED',
        targetType: 'USER',
        targetId: String(user.id),
        ipAddress: req.ip || null,
        details: { invalidatedCount },
      });
    }

    // Determine if connection is genuinely HTTPS (direct or reverse-proxy forwarded)
    const isConnectionSecure = Boolean(req.secure || req.headers['x-forwarded-proto'] === 'https');

    // Generate CSRF token for the authenticated session
    const csrfToken = generateCsrfToken();
    setCsrfCookie(res, csrfToken, isConnectionSecure);

    // Set secure HTTP-only session cookie (secure=false on plain LAN HTTP so phone browser saves it)
    res.cookie('kamch_session', rawToken, {
      httpOnly: true,
      secure: isConnectionSecure,
      sameSite: 'lax',
      path: '/',
      maxAge: SESSION_DURATION_MS,
    });

    await recordAuditLog({
      actorId: user.id,
      action: 'LOGIN_SUCCESS',
      targetType: 'USER',
      targetId: String(user.id),
      ipAddress: req.ip || null,
      details: { role: user.role_code, mustChangePassword: Boolean(user.must_change_password) },
    });

    // Return sanitized user profile (never returns password hashes or session tokens)
    res.json({
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        fullName: user.full_name,
        role: user.role_code,
        roleName: user.role_name,
        mustChangePassword: Boolean(user.must_change_password),
        departmentId: user.department_id || null,
      },
      csrfToken,
    });
  } catch (err) {
    await connection.rollback();
    console.error('[KAMCH Auth] Login error:', (err as Error).message);
    res.status(500).json({
      error: 'Internal server error during authentication',
      code: 'LOGIN_INTERNAL_ERROR',
    });
  } finally {
    connection.release();
  }
});

/**
 * GET /api/auth/me
 * Returns authenticated user details and flags. Protected by session verification.
 */
authRouter.get('/me', requireAuth, (req: Request, res: Response) => {
  let csrfToken = req.cookies?.kamch_csrf;
  const isSecure = Boolean(req.secure || req.headers['x-forwarded-proto'] === 'https');
  if (!csrfToken || typeof csrfToken !== 'string') {
    csrfToken = generateCsrfToken();
    setCsrfCookie(res, csrfToken, isSecure);
  }

  res.json({
    user: req.user,
    csrfToken,
  });
});

/**
 * POST /api/auth/change-password
 * First-login or user password change:
 * - Requires authentication and CSRF token
 * - Requires current password confirmation
 * - Enforces minimum 8 characters
 * - Hashes with bcrypt (salt rounds 12)
 * - Clears must_change_password flag
 */
authRouter.post('/change-password', requireAuth, validateCsrf, async (req: Request, res: Response): Promise<void> => {
  const { currentPassword, newPassword } = req.body || {};

  if (!currentPassword || !newPassword || typeof currentPassword !== 'string' || typeof newPassword !== 'string') {
    res.status(400).json({
      error: 'Current password and new password are required',
      code: 'MISSING_FIELDS',
    });
    return;
  }

  if (newPassword.length < 8) {
    res.status(400).json({
      error: 'New password must be at least 8 characters long',
      code: 'PASSWORD_TOO_SHORT',
    });
    return;
  }

  const userId = req.user!.id;
  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [rows] = await connection.query<any[]>(
      'SELECT password_hash FROM users WHERE id = ? LIMIT 1 FOR UPDATE',
      [userId]
    );

    if (!rows || rows.length === 0) {
      await connection.rollback();
      res.status(404).json({
        error: 'User account not found',
        code: 'USER_NOT_FOUND',
      });
      return;
    }

    const isCurrentValid = await bcrypt.compare(currentPassword, rows[0].password_hash);

    if (!isCurrentValid) {
      await connection.rollback();
      await recordAuditLog({
        actorId: userId,
        action: 'PASSWORD_CHANGE_FAILED',
        targetType: 'USER',
        targetId: String(userId),
        ipAddress: req.ip || null,
        details: { reason: 'incorrect_current_password' },
      });

      res.status(400).json({
        error: 'Current password does not match our records',
        code: 'INVALID_CURRENT_PASSWORD',
      });
      return;
    }

    // Hash new password using bcrypt
    const newHash = await bcrypt.hash(newPassword, 12);

    await connection.query(
      'UPDATE users SET password_hash = ?, must_change_password = FALSE WHERE id = ?',
      [newHash, userId]
    );

    await connection.commit();

    await recordAuditLog({
      actorId: userId,
      action: 'PASSWORD_CHANGED',
      targetType: 'USER',
      targetId: String(userId),
      ipAddress: req.ip || null,
      details: { mustChangePasswordCleared: true },
    });

    res.json({
      success: true,
      message: 'Password changed successfully. Your account is now fully active.',
    });
  } catch (err) {
    await connection.rollback();
    console.error('[KAMCH Auth] Password change error:', (err as Error).message);
    res.status(500).json({
      error: 'Internal error changing password',
      code: 'PASSWORD_CHANGE_INTERNAL_ERROR',
    });
  } finally {
    connection.release();
  }
});

/**
 * POST /api/auth/logout
 * Terminates session in database, clears HTTP-only cookie, and logs audit record.
 */
authRouter.post('/logout', validateCsrf, async (req: Request, res: Response): Promise<void> => {
  const token = req.cookies?.kamch_session;

  if (token && typeof token === 'string') {
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    try {
      const pool = getPool();
      const [rows] = await pool.query<any[]>(
        'SELECT id, user_id FROM sessions WHERE token_hash = ? LIMIT 1',
        [tokenHash]
      );

      if (rows && rows.length > 0) {
        await pool.query('UPDATE sessions SET is_active = FALSE WHERE id = ?', [rows[0].id]);
        await recordAuditLog({
          actorId: rows[0].user_id,
          action: 'LOGOUT',
          targetType: 'SESSION',
          targetId: String(rows[0].id),
          ipAddress: req.ip || null,
        });
      }
    } catch (err) {
      console.warn('[KAMCH Auth] Error during session logout cleanup:', (err as Error).message);
    }
  }

  res.clearCookie('kamch_session', { path: '/' });
  res.clearCookie('kamch_csrf', { path: '/' });

  res.json({
    success: true,
    message: 'Logged out successfully',
  });
});
