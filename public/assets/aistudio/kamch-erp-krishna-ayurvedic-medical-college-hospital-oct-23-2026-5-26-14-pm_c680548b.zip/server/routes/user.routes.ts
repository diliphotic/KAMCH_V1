import { Router, Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { getPool } from '../db.ts';
import { requireAuth, requirePasswordChangeClear, requireRoles } from '../middleware/auth.ts';
import { validateCsrf } from '../middleware/csrf.ts';
import { recordAuditLog } from '../services/audit.ts';

export const userRouter = Router();

// Apply session authentication and mandatory password-change clearance to all user-management routes
userRouter.use(requireAuth);
userRouter.use(requirePasswordChangeClear);

/**
 * GET /api/users/roles
 * Returns institutional roles for selection dropdowns.
 * Protected: Super Admin role is hidden from non-Super-Admin users.
 */
userRouter.get('/roles', requireRoles('SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY'), async (req: Request, res: Response): Promise<void> => {
  try {
    const pool = getPool();
    const isSuperAdmin = req.user!.role === 'SUPER_ADMIN';

    const [rows] = await pool.query<any[]>(
      'SELECT id, code, name, description FROM roles ORDER BY id ASC'
    );

    const filteredRoles = isSuperAdmin ? rows : rows.filter((r) => r.code !== 'SUPER_ADMIN');
    res.json({ roles: filteredRoles });
  } catch (err) {
    console.error('[KAMCH Users] Error fetching roles:', (err as Error).message);
    res.status(500).json({ error: 'Failed to retrieve roles', code: 'DATABASE_ERROR' });
  }
});

/**
 * GET /api/users/departments
 * Returns all institutional academic and clinical departments.
 */
userRouter.get('/departments', requireRoles('SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY'), async (_req: Request, res: Response): Promise<void> => {
  try {
    const pool = getPool();
    const [rows] = await pool.query<any[]>(
      'SELECT id, code, name, description FROM departments ORDER BY name ASC'
    );
    res.json({ departments: rows });
  } catch (err) {
    console.error('[KAMCH Users] Error fetching departments:', (err as Error).message);
    res.status(500).json({ error: 'Failed to retrieve departments', code: 'DATABASE_ERROR' });
  }
});

/**
 * POST /api/users/departments
 * Super Admin creates an institutional department.
 */
userRouter.post('/departments', requireRoles('SUPER_ADMIN'), validateCsrf, async (req: Request, res: Response): Promise<void> => {
  const { code, name, description } = req.body || {};

  if (!code || !name) {
    res.status(400).json({ error: 'Department code and name are required', code: 'MISSING_FIELDS' });
    return;
  }

  const cleanCode = String(code).trim().toUpperCase();
  const cleanName = String(name).trim();
  const cleanDesc = description ? String(description).trim() : null;

  try {
    const pool = getPool();
    const [existing] = await pool.query<any[]>(
      'SELECT id FROM departments WHERE code = ? LIMIT 1',
      [cleanCode]
    );

    if (existing && existing.length > 0) {
      res.status(409).json({ error: 'A department with this code already exists', code: 'DUPLICATE_CODE' });
      return;
    }

    const [result] = await pool.query<any>(
      'INSERT INTO departments (code, name, description) VALUES (?, ?, ?)',
      [cleanCode, cleanName, cleanDesc]
    );

    await recordAuditLog({
      actorId: req.user!.id,
      action: 'DEPARTMENT_CREATED',
      targetType: 'DEPARTMENT',
      targetId: String(result.insertId),
      ipAddress: req.ip || null,
      details: { code: cleanCode, name: cleanName },
    });

    res.status(201).json({
      success: true,
      department: {
        id: result.insertId,
        code: cleanCode,
        name: cleanName,
        description: cleanDesc,
      },
    });
  } catch (err) {
    console.error('[KAMCH Users] Error creating department:', (err as Error).message);
    res.status(500).json({ error: 'Failed to create department', code: 'DATABASE_ERROR' });
  }
});

/**
 * PUT /api/users/departments/:id
 * Super Admin updates an institutional department.
 */
userRouter.put('/departments/:id', requireRoles('SUPER_ADMIN'), validateCsrf, async (req: Request, res: Response): Promise<void> => {
  const deptId = parseInt(req.params.id, 10);
  const { name, description } = req.body || {};

  if (!deptId || isNaN(deptId)) {
    res.status(400).json({ error: 'Invalid department ID', code: 'INVALID_ID' });
    return;
  }

  if (!name) {
    res.status(400).json({ error: 'Department name is required', code: 'MISSING_FIELDS' });
    return;
  }

  const cleanName = String(name).trim();
  const cleanDesc = description ? String(description).trim() : null;

  try {
    const pool = getPool();
    const [rows] = await pool.query<any[]>(
      'SELECT id, name FROM departments WHERE id = ? LIMIT 1',
      [deptId]
    );

    if (!rows || rows.length === 0) {
      res.status(404).json({ error: 'Department not found', code: 'NOT_FOUND' });
      return;
    }

    await pool.query(
      'UPDATE departments SET name = ?, description = ? WHERE id = ?',
      [cleanName, cleanDesc, deptId]
    );

    await recordAuditLog({
      actorId: req.user!.id,
      action: 'DEPARTMENT_UPDATED',
      targetType: 'DEPARTMENT',
      targetId: String(deptId),
      ipAddress: req.ip || null,
      details: { before: rows[0].name, after: cleanName },
    });

    res.json({
      success: true,
      department: { id: deptId, name: cleanName, description: cleanDesc },
    });
  } catch (err) {
    console.error('[KAMCH Users] Error updating department:', (err as Error).message);
    res.status(500).json({ error: 'Failed to update department', code: 'DATABASE_ERROR' });
  }
});

/**
 * GET /api/users
 * Lists and searches institutional accounts with pagination and filtering.
 * Authorized for: SUPER_ADMIN, PRINCIPAL, SECRETARY.
 * STRICT SECURITY: Principal and Secretary must NEVER see or query the Super Admin account.
 */
userRouter.get('/', requireRoles('SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY'), async (req: Request, res: Response): Promise<void> => {
  const search = typeof req.query.search === 'string' ? req.query.search.trim() : '';
  const roleFilter = typeof req.query.role === 'string' ? req.query.role.trim() : '';
  const statusFilter = typeof req.query.status === 'string' ? req.query.status.trim() : '';
  const page = Math.max(1, parseInt(req.query.page as string, 10) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(req.query.limit as string, 10) || 20));
  const offset = (page - 1) * limit;

  try {
    const pool = getPool();
    const whereClauses: string[] = [];
    const queryParams: any[] = [];

    // STRICT PROTECTION: Principal and Secretary can NEVER see Super Admin
    if (req.user!.role !== 'SUPER_ADMIN') {
      whereClauses.push("r.code != 'SUPER_ADMIN'");
    }

    if (search) {
      whereClauses.push('(u.username LIKE ? OR u.email LIKE ? OR u.full_name LIKE ?)');
      const searchPattern = `%${search}%`;
      queryParams.push(searchPattern, searchPattern, searchPattern);
    }

    if (roleFilter && roleFilter !== 'ALL') {
      whereClauses.push('r.code = ?');
      queryParams.push(roleFilter);
    }

    if (statusFilter === 'DEACTIVATED') {
      whereClauses.push('u.is_deactivated = TRUE');
    } else if (statusFilter === 'LOCKED') {
      whereClauses.push('u.is_locked = TRUE');
    } else if (statusFilter === 'SUSPENDED') {
      whereClauses.push('u.is_suspended = TRUE AND u.is_deactivated = FALSE');
    } else if (statusFilter === 'ACTIVE') {
      whereClauses.push('u.is_locked = FALSE AND u.is_suspended = FALSE AND u.is_deactivated = FALSE');
    }

    const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

    // Total count query
    const [countRows] = await pool.query<any[]>(
      `SELECT COUNT(*) AS total 
       FROM users u 
       JOIN roles r ON u.role_id = r.id 
       ${whereSql}`,
      queryParams
    );
    const total = countRows[0]?.total || 0;

    // Accounts list query (Never selects password_hash)
    const [rows] = await pool.query<any[]>(
      `SELECT 
        u.id, 
        u.username, 
        u.email, 
        u.full_name, 
        u.role_id, 
        r.code AS role_code, 
        r.name AS role_name,
        u.department_id,
        d.name AS department_name,
        d.code AS department_code,
        u.must_change_password, 
        u.failed_attempts, 
        u.is_locked, 
        u.locked_at, 
        u.is_suspended, 
        u.suspended_at, 
        u.is_deactivated,
        u.deactivated_at,
        u.created_by,
        creator.username AS created_by_username,
        u.created_at, 
        u.updated_at
       FROM users u
       JOIN roles r ON u.role_id = r.id
       LEFT JOIN departments d ON u.department_id = d.id
       LEFT JOIN users creator ON u.created_by = creator.id
       ${whereSql}
       ORDER BY u.id DESC
       LIMIT ? OFFSET ?`,
      [...queryParams, limit, offset]
    );

    res.json({
      users: rows.map((u) => ({
        id: u.id,
        username: u.username,
        email: u.email,
        fullName: u.full_name,
        roleId: u.role_id,
        role: u.role_code,
        roleName: u.role_name,
        departmentId: u.department_id || null,
        departmentName: u.department_name || null,
        departmentCode: u.department_code || null,
        mustChangePassword: Boolean(u.must_change_password),
        failedAttempts: u.failed_attempts,
        isLocked: Boolean(u.is_locked),
        lockedAt: u.locked_at,
        isSuspended: Boolean(u.is_suspended),
        suspendedAt: u.suspended_at,
        isDeactivated: Boolean(u.is_deactivated),
        deactivatedAt: u.deactivated_at,
        createdBy: u.created_by_username || null,
        createdAt: u.created_at,
        updatedAt: u.updated_at,
      })),
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit) || 1,
      },
    });
  } catch (err) {
    console.error('[KAMCH Users] Error listing accounts:', (err as Error).message);
    res.status(500).json({ error: 'Failed to retrieve accounts', code: 'DATABASE_ERROR' });
  }
});

/**
 * GET /api/users/:id
 * Retrieves details for a specific user.
 * STRICT SECURITY: Principal and Secretary cannot access Super Admin account details.
 */
userRouter.get('/:id', requireRoles('SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY'), async (req: Request, res: Response): Promise<void> => {
  const targetId = parseInt(req.params.id, 10);
  if (!targetId || isNaN(targetId)) {
    res.status(400).json({ error: 'Invalid user ID', code: 'INVALID_ID' });
    return;
  }

  try {
    const pool = getPool();
    const [rows] = await pool.query<any[]>(
      `SELECT 
        u.id, 
        u.username, 
        u.email, 
        u.full_name, 
        u.role_id, 
        r.code AS role_code, 
        r.name AS role_name,
        u.department_id,
        d.name AS department_name,
        u.must_change_password, 
        u.failed_attempts, 
        u.is_locked, 
        u.locked_at, 
        u.is_suspended, 
        u.suspended_at, 
        u.is_deactivated,
        u.deactivated_at,
        u.created_at, 
        u.updated_at
       FROM users u
       JOIN roles r ON u.role_id = r.id
       LEFT JOIN departments d ON u.department_id = d.id
       WHERE u.id = ? LIMIT 1`,
      [targetId]
    );

    if (!rows || rows.length === 0) {
      res.status(404).json({ error: 'User account not found', code: 'USER_NOT_FOUND' });
      return;
    }

    const targetUser = rows[0];

    // Protection guard
    if (targetUser.role_code === 'SUPER_ADMIN' && req.user!.role !== 'SUPER_ADMIN') {
      res.status(403).json({
        error: 'Access denied: Insufficient permissions to view protected administrative account',
        code: 'FORBIDDEN_SUPERADMIN_TARGET',
      });
      return;
    }

    res.json({
      user: {
        id: targetUser.id,
        username: targetUser.username,
        email: targetUser.email,
        fullName: targetUser.full_name,
        roleId: targetUser.role_id,
        role: targetUser.role_code,
        roleName: targetUser.role_name,
        departmentId: targetUser.department_id || null,
        departmentName: targetUser.department_name || null,
        mustChangePassword: Boolean(targetUser.must_change_password),
        failedAttempts: targetUser.failed_attempts,
        isLocked: Boolean(targetUser.is_locked),
        lockedAt: targetUser.locked_at,
        isSuspended: Boolean(targetUser.is_suspended),
        suspendedAt: targetUser.suspended_at,
        isDeactivated: Boolean(targetUser.is_deactivated),
        deactivatedAt: targetUser.deactivated_at,
        createdAt: targetUser.created_at,
        updatedAt: targetUser.updated_at,
      },
    });
  } catch (err) {
    console.error('[KAMCH Users] Error fetching user:', (err as Error).message);
    res.status(500).json({ error: 'Failed to retrieve account details', code: 'DATABASE_ERROR' });
  }
});

/**
 * POST /api/users
 * Super Admin, Principal, and Secretary create a user account directly.
 * Newly created accounts require mandatory password change at first login.
 */
userRouter.post('/', requireRoles('SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY'), validateCsrf, async (req: Request, res: Response): Promise<void> => {
  const { username, email, fullName, roleId, departmentId, initialPassword, confirmPassword } = req.body || {};

  if (!username || !email || !fullName || !roleId || !initialPassword || !confirmPassword) {
    res.status(400).json({
      error: 'Username, email, full name, role, and temporary password are required',
      code: 'MISSING_FIELDS',
    });
    return;
  }

  const cleanUsername = String(username).trim();
  const cleanEmail = String(email).trim().toLowerCase();
  const cleanFullName = String(fullName).trim();
  const parsedRoleId = Number(roleId);
  const parsedDeptId = departmentId ? Number(departmentId) : null;

  if (cleanUsername.length < 3 || cleanUsername.length > 50) {
    res.status(400).json({ error: 'Username must be between 3 and 50 characters', code: 'INVALID_USERNAME' });
    return;
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(cleanEmail)) {
    res.status(400).json({ error: 'Please enter a valid institutional email address', code: 'INVALID_EMAIL' });
    return;
  }

  if (String(initialPassword).length < 8) {
    res.status(400).json({ error: 'Temporary password must be at least 8 characters long', code: 'PASSWORD_TOO_SHORT' });
    return;
  }

  if (initialPassword !== confirmPassword) {
    res.status(400).json({ error: 'Initial password and confirmation password do not match', code: 'PASSWORD_MISMATCH' });
    return;
  }

  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    // Verify role exists
    const [roleRows] = await connection.query<any[]>(
      'SELECT id, code, name FROM roles WHERE id = ? LIMIT 1',
      [parsedRoleId]
    );

    if (!roleRows || roleRows.length === 0) {
      await connection.rollback();
      res.status(400).json({ error: 'Selected institutional role is invalid', code: 'INVALID_ROLE' });
      return;
    }

    const targetRole = roleRows[0];

    // RESTRICTION: Only Super Admin can create another Super Admin (or non-Super-Admin cannot create Super Admin)
    if (targetRole.code === 'SUPER_ADMIN' && req.user!.role !== 'SUPER_ADMIN') {
      await connection.rollback();
      res.status(403).json({
        error: 'Security policy violation: Only Super Administrator can assign the Super Administrator role',
        code: 'FORBIDDEN_SUPERADMIN_CREATION',
      });
      return;
    }

    // If role is DEPARTMENT or HOD, verify department
    if (['DEPARTMENT', 'HOD'].includes(targetRole.code) && !parsedDeptId) {
      await connection.rollback();
      res.status(400).json({
        error: 'Department assignment is required for Department accounts',
        code: 'DEPARTMENT_REQUIRED',
      });
      return;
    }

    // Check duplicate username or email
    const [existing] = await connection.query<any[]>(
      'SELECT id, username, email FROM users WHERE username = ? OR email = ? LIMIT 1 FOR UPDATE',
      [cleanUsername, cleanEmail]
    );

    if (existing && existing.length > 0) {
      await connection.rollback();
      const conflictField = existing[0].username.toLowerCase() === cleanUsername.toLowerCase() ? 'Username' : 'Email address';
      res.status(409).json({
        error: `${conflictField} is already registered in the system`,
        code: 'DUPLICATE_USER',
      });
      return;
    }

    // Hash initial password using bcrypt
    const passwordHash = await bcrypt.hash(String(initialPassword), 12);

    // Insert user with must_change_password = TRUE
    const [insertResult] = await connection.query<any>(
      `INSERT INTO users 
        (username, email, password_hash, role_id, department_id, full_name, must_change_password, failed_attempts, is_locked, is_suspended, is_deactivated, created_by)
       VALUES (?, ?, ?, ?, ?, ?, TRUE, 0, FALSE, FALSE, FALSE, ?)`,
      [cleanUsername, cleanEmail, passwordHash, parsedRoleId, parsedDeptId, cleanFullName, req.user!.id]
    );

    const newUserId = insertResult.insertId;

    await recordAuditLog({
      actorId: req.user!.id,
      action: 'USER_CREATED',
      targetType: 'USER',
      targetId: String(newUserId),
      ipAddress: req.ip || null,
      details: {
        username: cleanUsername,
        email: cleanEmail,
        role: targetRole.code,
        departmentId: parsedDeptId,
        fullName: cleanFullName,
      },
    });

    await connection.commit();

    res.status(201).json({
      success: true,
      message: `Account created successfully for ${cleanFullName}. User must change password upon first login.`,
      user: {
        id: newUserId,
        username: cleanUsername,
        email: cleanEmail,
        fullName: cleanFullName,
        role: targetRole.code,
        roleName: targetRole.name,
        departmentId: parsedDeptId,
        mustChangePassword: true,
      },
    });
  } catch (err) {
    await connection.rollback();
    console.error('[KAMCH Users] Error creating user:', (err as Error).message);
    res.status(500).json({ error: 'Failed to create user account', code: 'DATABASE_ERROR' });
  } finally {
    connection.release();
  }
});

/**
 * PUT /api/users/:id
 * Edit account details (full name, email, role, department).
 * Authorized: SUPER_ADMIN, PRINCIPAL, SECRETARY.
 * STRICT GUARDS: Principal and Secretary cannot modify Super Admin accounts or elevate users to Super Admin.
 */
userRouter.put('/:id', requireRoles('SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY'), validateCsrf, async (req: Request, res: Response): Promise<void> => {
  const targetId = parseInt(req.params.id, 10);
  const { fullName, email, roleId, departmentId } = req.body || {};

  if (!targetId || isNaN(targetId)) {
    res.status(400).json({ error: 'Invalid user ID', code: 'INVALID_ID' });
    return;
  }

  if (!fullName || !email || !roleId) {
    res.status(400).json({ error: 'Full name, email, and role are required', code: 'MISSING_FIELDS' });
    return;
  }

  const cleanFullName = String(fullName).trim();
  const cleanEmail = String(email).trim().toLowerCase();
  const parsedRoleId = Number(roleId);
  const parsedDeptId = departmentId ? Number(departmentId) : null;

  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [targetRows] = await connection.query<any[]>(
      `SELECT u.id, u.username, u.email, u.full_name, u.role_id, r.code AS role_code, u.department_id 
       FROM users u 
       JOIN roles r ON u.role_id = r.id 
       WHERE u.id = ? LIMIT 1 FOR UPDATE`,
      [targetId]
    );

    if (!targetRows || targetRows.length === 0) {
      await connection.rollback();
      res.status(404).json({ error: 'User account not found', code: 'USER_NOT_FOUND' });
      return;
    }

    const targetUser = targetRows[0];

    // Protection: Non-Super-Admin cannot modify Super Admin
    if (targetUser.role_code === 'SUPER_ADMIN' && req.user!.role !== 'SUPER_ADMIN') {
      await connection.rollback();
      res.status(403).json({
        error: 'Security policy violation: Cannot modify Super Administrator account',
        code: 'FORBIDDEN_SUPERADMIN_TARGET',
      });
      return;
    }

    // Protection: Users cannot change their own role
    if (targetId === req.user!.id && targetUser.role_id !== parsedRoleId) {
      await connection.rollback();
      res.status(403).json({
        error: 'Security policy: You cannot change your own role to prevent accidental lockout or unauthorized elevation',
        code: 'CANNOT_CHANGE_OWN_ROLE',
      });
      return;
    }

    // Verify requested role exists
    const [roleRows] = await connection.query<any[]>(
      'SELECT id, code, name FROM roles WHERE id = ? LIMIT 1',
      [parsedRoleId]
    );

    if (!roleRows || roleRows.length === 0) {
      await connection.rollback();
      res.status(400).json({ error: 'Invalid institutional role', code: 'INVALID_ROLE' });
      return;
    }

    const newRole = roleRows[0];

    // Protection: Non-Super-Admin cannot elevate any account to Super Admin
    if (newRole.code === 'SUPER_ADMIN' && req.user!.role !== 'SUPER_ADMIN') {
      await connection.rollback();
      res.status(403).json({
        error: 'Security policy: Only Super Administrator can assign the Super Administrator role',
        code: 'FORBIDDEN_SUPERADMIN_ASSIGNMENT',
      });
      return;
    }

    // Check duplicate email if email was changed
    if (cleanEmail !== targetUser.email.toLowerCase()) {
      const [emailConflict] = await connection.query<any[]>(
        'SELECT id FROM users WHERE email = ? AND id != ? LIMIT 1',
        [cleanEmail, targetId]
      );
      if (emailConflict && emailConflict.length > 0) {
        await connection.rollback();
        res.status(409).json({ error: 'This email is already registered to another account', code: 'DUPLICATE_EMAIL' });
        return;
      }
    }

    // Update user
    await connection.query(
      'UPDATE users SET full_name = ?, email = ?, role_id = ?, department_id = ? WHERE id = ?',
      [cleanFullName, cleanEmail, parsedRoleId, parsedDeptId, targetId]
    );

    await recordAuditLog({
      actorId: req.user!.id,
      action: 'USER_UPDATED',
      targetType: 'USER',
      targetId: String(targetId),
      ipAddress: req.ip || null,
      details: {
        before: { fullName: targetUser.full_name, email: targetUser.email, role: targetUser.role_code },
        after: { fullName: cleanFullName, email: cleanEmail, role: newRole.code },
      },
    });

    await connection.commit();

    res.json({
      success: true,
      message: `Account details for ${cleanFullName} updated successfully.`,
      user: {
        id: targetId,
        username: targetUser.username,
        email: cleanEmail,
        fullName: cleanFullName,
        role: newRole.code,
        roleName: newRole.name,
        departmentId: parsedDeptId,
      },
    });
  } catch (err) {
    await connection.rollback();
    console.error('[KAMCH Users] Error updating user:', (err as Error).message);
    res.status(500).json({ error: 'Failed to update user account', code: 'DATABASE_ERROR' });
  } finally {
    connection.release();
  }
});

/**
 * PATCH /api/users/:id/suspend
 * Suspends an account and terminates all active sessions immediately.
 * Authorized for: SUPER_ADMIN, PRINCIPAL, SECRETARY.
 * STRICT GUARD: Principal and Secretary cannot suspend Super Admin accounts.
 */
userRouter.patch('/:id/suspend', requireRoles('SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY'), validateCsrf, async (req: Request, res: Response): Promise<void> => {
  const targetId = parseInt(req.params.id, 10);
  if (!targetId || isNaN(targetId)) {
    res.status(400).json({ error: 'Invalid user ID', code: 'INVALID_ID' });
    return;
  }

  if (targetId === req.user!.id) {
    res.status(400).json({ error: 'You cannot suspend your own account', code: 'SELF_ACTION_DENIED' });
    return;
  }

  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [rows] = await connection.query<any[]>(
      `SELECT u.id, u.username, u.full_name, r.code AS role_code 
       FROM users u 
       JOIN roles r ON u.role_id = r.id 
       WHERE u.id = ? LIMIT 1 FOR UPDATE`,
      [targetId]
    );

    if (!rows || rows.length === 0) {
      await connection.rollback();
      res.status(404).json({ error: 'User account not found', code: 'USER_NOT_FOUND' });
      return;
    }

    const targetUser = rows[0];

    // Protection: Non-Super-Admin cannot suspend Super Admin
    if (targetUser.role_code === 'SUPER_ADMIN' && req.user!.role !== 'SUPER_ADMIN') {
      await connection.rollback();
      res.status(403).json({
        error: 'Security policy violation: Cannot suspend Super Administrator accounts',
        code: 'FORBIDDEN_SUPERADMIN_TARGET',
      });
      return;
    }

    // Suspend user
    await connection.query(
      'UPDATE users SET is_suspended = TRUE, suspended_at = NOW() WHERE id = ?',
      [targetId]
    );

    // Invalidate all active sessions immediately
    const [sessionResult] = await connection.query<any>(
      'UPDATE sessions SET is_active = FALSE WHERE user_id = ? AND is_active = TRUE',
      [targetId]
    );

    await recordAuditLog({
      actorId: req.user!.id,
      action: 'ACCOUNT_SUSPENDED',
      targetType: 'USER',
      targetId: String(targetId),
      ipAddress: req.ip || null,
      details: {
        targetUsername: targetUser.username,
        role: targetUser.role_code,
        sessionsTerminated: sessionResult?.affectedRows || 0,
      },
    });

    await connection.commit();

    res.json({
      success: true,
      message: `Account for ${targetUser.full_name} (${targetUser.username}) has been suspended and active sessions terminated.`,
    });
  } catch (err) {
    await connection.rollback();
    console.error('[KAMCH Users] Error suspending user:', (err as Error).message);
    res.status(500).json({ error: 'Failed to suspend account', code: 'DATABASE_ERROR' });
  } finally {
    connection.release();
  }
});

/**
 * PATCH /api/users/:id/reactivate
 * Reactivates a suspended or deactivated account.
 * Authorized for: SUPER_ADMIN, PRINCIPAL, SECRETARY.
 * STRICT GUARD: Principal and Secretary cannot manage Super Admin accounts.
 */
userRouter.patch('/:id/reactivate', requireRoles('SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY'), validateCsrf, async (req: Request, res: Response): Promise<void> => {
  const targetId = parseInt(req.params.id, 10);
  if (!targetId || isNaN(targetId)) {
    res.status(400).json({ error: 'Invalid user ID', code: 'INVALID_ID' });
    return;
  }

  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [rows] = await connection.query<any[]>(
      `SELECT u.id, u.username, u.full_name, r.code AS role_code 
       FROM users u 
       JOIN roles r ON u.role_id = r.id 
       WHERE u.id = ? LIMIT 1 FOR UPDATE`,
      [targetId]
    );

    if (!rows || rows.length === 0) {
      await connection.rollback();
      res.status(404).json({ error: 'User account not found', code: 'USER_NOT_FOUND' });
      return;
    }

    const targetUser = rows[0];

    if (targetUser.role_code === 'SUPER_ADMIN' && req.user!.role !== 'SUPER_ADMIN') {
      await connection.rollback();
      res.status(403).json({
        error: 'Security policy violation: Cannot manage Super Administrator accounts',
        code: 'FORBIDDEN_SUPERADMIN_TARGET',
      });
      return;
    }

    await connection.query(
      'UPDATE users SET is_suspended = FALSE, suspended_at = NULL, is_deactivated = FALSE, deactivated_at = NULL WHERE id = ?',
      [targetId]
    );

    await recordAuditLog({
      actorId: req.user!.id,
      action: 'ACCOUNT_REACTIVATED',
      targetType: 'USER',
      targetId: String(targetId),
      ipAddress: req.ip || null,
      details: { targetUsername: targetUser.username, role: targetUser.role_code },
    });

    await connection.commit();

    res.json({
      success: true,
      message: `Account for ${targetUser.full_name} has been reactivated.`,
    });
  } catch (err) {
    await connection.rollback();
    console.error('[KAMCH Users] Error reactivating user:', (err as Error).message);
    res.status(500).json({ error: 'Failed to reactivate account', code: 'DATABASE_ERROR' });
  } finally {
    connection.release();
  }
});

/**
 * PATCH /api/users/:id/deactivate
 * Deactivates an account, preserving historical references (fees, payments, marks, audits).
 * Invalides active sessions immediately.
 * Authorized for: SUPER_ADMIN, PRINCIPAL, SECRETARY.
 * STRICT GUARDS:
 * - Principal and Secretary cannot deactivate Super Admin accounts.
 * - Cannot deactivate own account.
 * - Cannot deactivate the last remaining Super Admin account.
 */
userRouter.patch('/:id/deactivate', requireRoles('SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY'), validateCsrf, async (req: Request, res: Response): Promise<void> => {
  const targetId = parseInt(req.params.id, 10);
  if (!targetId || isNaN(targetId)) {
    res.status(400).json({ error: 'Invalid user ID', code: 'INVALID_ID' });
    return;
  }

  if (targetId === req.user!.id) {
    res.status(400).json({ error: 'You cannot deactivate your own account', code: 'SELF_ACTION_DENIED' });
    return;
  }

  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [rows] = await connection.query<any[]>(
      `SELECT u.id, u.username, u.full_name, r.code AS role_code 
       FROM users u 
       JOIN roles r ON u.role_id = r.id 
       WHERE u.id = ? LIMIT 1 FOR UPDATE`,
      [targetId]
    );

    if (!rows || rows.length === 0) {
      await connection.rollback();
      res.status(404).json({ error: 'User account not found', code: 'USER_NOT_FOUND' });
      return;
    }

    const targetUser = rows[0];

    // Protection: Non-Super-Admin cannot deactivate Super Admin
    if (targetUser.role_code === 'SUPER_ADMIN' && req.user!.role !== 'SUPER_ADMIN') {
      await connection.rollback();
      res.status(403).json({
        error: 'Security policy violation: Cannot deactivate Super Administrator accounts',
        code: 'FORBIDDEN_SUPERADMIN_TARGET',
      });
      return;
    }

    // Protection: Prevent deactivating the last active Super Admin
    if (targetUser.role_code === 'SUPER_ADMIN') {
      const [adminCountRows] = await connection.query<any[]>(
        `SELECT COUNT(*) AS active_admins 
         FROM users u 
         JOIN roles r ON u.role_id = r.id 
         WHERE r.code = 'SUPER_ADMIN' AND u.is_deactivated = FALSE AND u.id != ?`,
        [targetId]
      );
      if (!adminCountRows || adminCountRows[0].active_admins === 0) {
        await connection.rollback();
        res.status(400).json({
          error: 'Cannot deactivate the last functional Super Administrator account',
          code: 'LAST_ADMIN_PROTECTED',
        });
        return;
      }
    }

    // Deactivate user
    await connection.query(
      'UPDATE users SET is_deactivated = TRUE, deactivated_at = NOW() WHERE id = ?',
      [targetId]
    );

    // Invalidate all active sessions immediately
    const [sessionResult] = await connection.query<any>(
      'UPDATE sessions SET is_active = FALSE WHERE user_id = ? AND is_active = TRUE',
      [targetId]
    );

    await recordAuditLog({
      actorId: req.user!.id,
      action: 'ACCOUNT_DEACTIVATED',
      targetType: 'USER',
      targetId: String(targetId),
      ipAddress: req.ip || null,
      details: {
        targetUsername: targetUser.username,
        role: targetUser.role_code,
        sessionsTerminated: sessionResult?.affectedRows || 0,
      },
    });

    await connection.commit();

    res.json({
      success: true,
      message: `Account for ${targetUser.full_name} (${targetUser.username}) has been deactivated. Historical records remain fully preserved.`,
    });
  } catch (err) {
    await connection.rollback();
    console.error('[KAMCH Users] Error deactivating user:', (err as Error).message);
    res.status(500).json({ error: 'Failed to deactivate account', code: 'DATABASE_ERROR' });
  } finally {
    connection.release();
  }
});

/**
 * PATCH /api/users/:id/unlock
 * Manually unlocks an account that was locked after consecutive failed login attempts.
 * Resets failed_attempts counter to 0.
 * Authorized for: SUPER_ADMIN, PRINCIPAL, SECRETARY.
 * STRICT GUARD: Principal and Secretary cannot unlock Super Admin accounts.
 */
userRouter.patch('/:id/unlock', requireRoles('SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY'), validateCsrf, async (req: Request, res: Response): Promise<void> => {
  const targetId = parseInt(req.params.id, 10);
  if (!targetId || isNaN(targetId)) {
    res.status(400).json({ error: 'Invalid user ID', code: 'INVALID_ID' });
    return;
  }

  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [rows] = await connection.query<any[]>(
      `SELECT u.id, u.username, u.full_name, r.code AS role_code, u.is_locked 
       FROM users u 
       JOIN roles r ON u.role_id = r.id 
       WHERE u.id = ? LIMIT 1 FOR UPDATE`,
      [targetId]
    );

    if (!rows || rows.length === 0) {
      await connection.rollback();
      res.status(404).json({ error: 'User account not found', code: 'USER_NOT_FOUND' });
      return;
    }

    const targetUser = rows[0];

    if (targetUser.role_code === 'SUPER_ADMIN' && req.user!.role !== 'SUPER_ADMIN') {
      await connection.rollback();
      res.status(403).json({
        error: 'Security policy violation: Cannot manage Super Administrator accounts',
        code: 'FORBIDDEN_SUPERADMIN_TARGET',
      });
      return;
    }

    // Reset failed_attempts and is_locked flag
    await connection.query(
      'UPDATE users SET is_locked = FALSE, locked_at = NULL, failed_attempts = 0 WHERE id = ?',
      [targetId]
    );

    await recordAuditLog({
      actorId: req.user!.id,
      action: 'ACCOUNT_UNLOCKED',
      targetType: 'USER',
      targetId: String(targetId),
      ipAddress: req.ip || null,
      details: { targetUsername: targetUser.username },
    });

    await connection.commit();

    res.json({
      success: true,
      message: `Account for ${targetUser.full_name} (${targetUser.username}) unlocked. Failure counter reset to 0.`,
    });
  } catch (err) {
    await connection.rollback();
    console.error('[KAMCH Users] Error unlocking user:', (err as Error).message);
    res.status(500).json({ error: 'Failed to unlock account', code: 'DATABASE_ERROR' });
  } finally {
    connection.release();
  }
});

/**
 * POST /api/users/:id/reset-password
 * Super Admin, Principal, or Secretary resets another user's password.
 * - Sets a new temporary password.
 * - Sets must_change_password = TRUE.
 * - Invalidates all active sessions for the user.
 * - Never logs or reveals the password.
 * - STRICT GUARD: Principal and Secretary cannot reset Super Admin passwords.
 */
userRouter.post('/:id/reset-password', requireRoles('SUPER_ADMIN', 'PRINCIPAL', 'SECRETARY'), validateCsrf, async (req: Request, res: Response): Promise<void> => {
  const targetId = parseInt(req.params.id, 10);
  const { temporaryPassword, confirmPassword } = req.body || {};

  if (!targetId || isNaN(targetId)) {
    res.status(400).json({ error: 'Invalid user ID', code: 'INVALID_ID' });
    return;
  }

  if (!temporaryPassword || String(temporaryPassword).length < 8) {
    res.status(400).json({ error: 'Temporary password must be at least 8 characters long', code: 'PASSWORD_TOO_SHORT' });
    return;
  }

  if (temporaryPassword !== confirmPassword) {
    res.status(400).json({ error: 'Temporary password and confirmation password do not match', code: 'PASSWORD_MISMATCH' });
    return;
  }

  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [rows] = await connection.query<any[]>(
      `SELECT u.id, u.username, u.full_name, r.code AS role_code 
       FROM users u 
       JOIN roles r ON u.role_id = r.id 
       WHERE u.id = ? LIMIT 1 FOR UPDATE`,
      [targetId]
    );

    if (!rows || rows.length === 0) {
      await connection.rollback();
      res.status(404).json({ error: 'User account not found', code: 'USER_NOT_FOUND' });
      return;
    }

    const targetUser = rows[0];

    // Protection: Non-Super-Admin cannot reset Super Admin password
    if (targetUser.role_code === 'SUPER_ADMIN' && req.user!.role !== 'SUPER_ADMIN') {
      await connection.rollback();
      res.status(403).json({
        error: 'Security policy violation: Cannot reset password for Super Administrator account',
        code: 'FORBIDDEN_SUPERADMIN_TARGET',
      });
      return;
    }

    // Hash new temporary password using bcrypt
    const newHash = await bcrypt.hash(String(temporaryPassword), 12);

    // Update password and set must_change_password = TRUE
    await connection.query(
      'UPDATE users SET password_hash = ?, must_change_password = TRUE, failed_attempts = 0, is_locked = FALSE, locked_at = NULL WHERE id = ?',
      [newHash, targetId]
    );

    // Invalidate all active sessions immediately
    const [sessionResult] = await connection.query<any>(
      'UPDATE sessions SET is_active = FALSE WHERE user_id = ? AND is_active = TRUE',
      [targetId]
    );

    await recordAuditLog({
      actorId: req.user!.id,
      action: 'PASSWORD_RESET_BY_ADMIN',
      targetType: 'USER',
      targetId: String(targetId),
      ipAddress: req.ip || null,
      details: {
        targetUsername: targetUser.username,
        role: targetUser.role_code,
        sessionsTerminated: sessionResult?.affectedRows || 0,
      },
    });

    await connection.commit();

    res.json({
      success: true,
      message: `Password reset successfully for ${targetUser.full_name}. Target user will be required to change this password upon next sign in. All active sessions have been terminated.`,
    });
  } catch (err) {
    await connection.rollback();
    console.error('[KAMCH Users] Error resetting user password:', (err as Error).message);
    res.status(500).json({ error: 'Failed to reset password', code: 'DATABASE_ERROR' });
  } finally {
    connection.release();
  }
});
