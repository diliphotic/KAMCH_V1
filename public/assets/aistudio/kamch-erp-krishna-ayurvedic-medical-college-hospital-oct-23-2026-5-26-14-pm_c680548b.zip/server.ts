import './server/env.ts';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import cookieParser from 'cookie-parser';
import { checkDatabaseConnection } from './server/db.ts';
import { authRouter } from './server/routes/auth.routes.ts';
import { userRouter } from './server/routes/user.routes.ts';
import { feesRouter } from './server/routes/fees.routes.ts';
import { logInfo, logError } from './server/services/logger.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Validate environment configuration
function validateEnvironment(): { port: number; isProduction: boolean } {
  const rawPort = process.env.PORT;
  let port = 3000;

  if (rawPort !== undefined && rawPort.trim() !== '') {
    const parsedPort = Number(rawPort);
    if (!Number.isInteger(parsedPort) || parsedPort < 1 || parsedPort > 65535) {
      throw new Error(
        `[KAMCH ERP Configuration Error] Invalid PORT environment variable: "${rawPort}". Expected a positive integer between 1 and 65535.`
      );
    }
    port = parsedPort;
  }

  const isProduction = process.env.NODE_ENV === 'production';
  return { port, isProduction };
}

const { port: PORT, isProduction } = validateEnvironment();

async function startServer() {
  const app = express();
  app.use(express.json());
  app.use(cookieParser());

  // Mount Institutional Module Routers
  app.use('/api/auth', authRouter);
  app.use('/api/users', userRouter);
  app.use('/api/fees', feesRouter);

  // Base Foundation Health & Architecture API endpoint
  app.get('/api/foundation', (_req, res) => {
    res.json({
      status: 'active',
      system: 'KAMCH ERP Foundation',
      institution: 'Krishna Ayurvedic Medical College and Hospital',
      database: 'MySQL (Target Architecture for future modules)',
      runtime: 'Node.js + Express',
      frontend: 'React 19 + TypeScript + Tailwind CSS',
      phase: 'Phase 1: Foundation Baseline',
      environment: {
        nodeEnv: isProduction ? 'production' : 'development',
        port: PORT,
        dbConfigured: Boolean(process.env.DB_HOST && process.env.DB_NAME),
      },
    });
  });

  // MySQL Database Verification endpoint (performs real harmless ping query without exposing credentials)
  app.get('/api/health/database', async (_req, res) => {
    try {
      const dbStatus = await checkDatabaseConnection();
      if (dbStatus.connected) {
        return res.status(200).json({
          status: 'connected',
          database: 'MySQL',
          targetDatabase: process.env.DB_NAME || 'kamch_erp',
          latencyMs: dbStatus.latencyMs,
          verifiedAt: new Date().toISOString(),
        });
      } else {
        return res.status(503).json({
          status: 'disconnected',
          database: 'MySQL',
          targetDatabase: process.env.DB_NAME || 'kamch_erp',
          code: dbStatus.code,
          message: 'Database connection failed. Ensure MySQL service is running.',
          verifiedAt: new Date().toISOString(),
        });
      }
    } catch {
      return res.status(500).json({
        status: 'error',
        database: 'MySQL',
        message: 'Internal error checking database connectivity.',
        verifiedAt: new Date().toISOString(),
      });
    }
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
        watch: process.env.DISABLE_HMR === 'true' ? null : {},
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static production build
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    const startupMsg = `Institutional Server running at http://localhost:${PORT} (Node: ${process.version}, PID: ${process.pid})`;
    console.log(`[KAMCH ERP] ${startupMsg}`);
    logInfo('STARTUP', startupMsg);

    // Non-blocking database connection verification on startup
    checkDatabaseConnection()
      .then((status) => {
        if (status.connected) {
          const dbMsg = `MySQL connection verified successfully (latency: ${status.latencyMs}ms).`;
          console.log(`[KAMCH ERP Database] ${dbMsg}`);
          logInfo('DATABASE', dbMsg);
        } else {
          const dbWarn = `MySQL service not reachable (${status.code || 'UNKNOWN'}). Server operational in standalone mode. Note: ${status.diagnosticNote || 'Check MySQL service'}`;
          console.warn(`[KAMCH ERP Database] ${dbWarn}`);
          logError('DATABASE', dbWarn);
        }
      })
      .catch((err) => {
        const errStr = (err as Error).message;
        console.warn('[KAMCH ERP Database] Startup connection check encountered error:', errStr);
        logError('DATABASE', 'Startup connection check encountered error', err);
      });
  });
}

// Global unhandled error logging
process.on('unhandledRejection', (reason) => {
  logError('UNHANDLED_REJECTION', 'Unhandled promise rejection in server process', reason);
});

process.on('uncaughtException', (err) => {
  logError('UNCAUGHT_EXCEPTION', 'Uncaught exception in server process', err);
  process.exit(1);
});

startServer().catch((err) => {
  console.error('[KAMCH ERP] Server failed to start:', err);
  logError('STARTUP_FAILED', 'Server failed to start during initialization', err);
  process.exit(1);
});
